import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

import 'package:Zentry/l10n/generated/app_localizations.dart';
import 'package:Zentry/theme/theme_controller.dart';

import 'media_grid_widget.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() =>
      _ChatScreenState();
}

class _ChatScreenState
    extends State<ChatScreen>
    with SingleTickerProviderStateMixin {

  late TabController
      _tabController;

  bool isChatOpen = false;

  String currentChatName = "";

  final ImagePicker _picker =
      ImagePicker();

  final TextEditingController
      _controller =
      TextEditingController();

  final ScrollController
      _scroll =
      ScrollController();

  final AudioRecorder _recorder =
      AudioRecorder();

  bool isRecording = false;

  String? audioPath;

  List<Map<String, dynamic>>
      messages = [];

  @override
  void initState() {

    super.initState();

    _tabController =
        TabController(
      length: 3,
      vsync: this,
    );
  }

  void openChat(String name) {

    setState(() {

      isChatOpen = true;

      currentChatName = name;

      messages = [
        {
          'type': 'text',

          'text': 'Hola 👋',

          'isMe': false,
        },
      ];
    });
  }

  void sendText() {

    if (_controller.text
        .trim()
        .isEmpty) return;

    setState(() {

      messages.add({

        'type': 'text',

        'text':
            _controller.text,

        'isMe': true,
      });
    });

    _controller.clear();

    scrollDown();
  }

  Future<void> pickImage() async {

    final List<AssetEntity>?
        assets =
        await AssetPicker.pickAssets(
      context,

      pickerConfig:
          const AssetPickerConfig(
        maxAssets: 10,

        requestType:
            RequestType.image,
      ),
    );

    if (assets == null) return;

    List<File> files = [];

    for (final asset in assets) {

      final file =
          await asset.file;

      if (file != null) {

        files.add(file);
      }
    }

    setState(() {

      messages.add({

        'type':
            'media_group',

        'mediaType':
            'image',

        'files': files,

        'isMe': true,
      });
    });

    scrollDown();
  }

  
  Future<void> pickVideo() async {

    final List<AssetEntity>?
        assets =
        await AssetPicker.pickAssets(
      context,

      pickerConfig:
          const AssetPickerConfig(
        maxAssets: 10,

        requestType:
            RequestType.video,
      ),
    );

    if (assets == null) return;

    List<File> files = [];

    for (final asset in assets) {

      final file =
          await asset.file;

      if (file != null) {

        files.add(file);
      }
    }

    setState(() {

      messages.add({

        'type':
            'media_group',

        'mediaType':
            'video',

        'files': files,

        'isMe': true,
      });
    });

    scrollDown();
  }

  Future<void> pickFile() async {

    final result =
        await FilePicker.platform
            .pickFiles(
      allowMultiple: true,
    );

    if (result == null) return;

    setState(() {

      for (var f
          in result.files) {

        messages.add({

          'type': 'file',

          'file':
              File(f.path!),

          'name': f.name,

          'size': f.size,

          'isMe': true,
        });
      }
    });

    scrollDown();
  }

  Future<void>
      toggleRecording() async {

    final status =
        await Permission.microphone
            .request();

    if (!status.isGranted) return;

    if (!isRecording) {

      final dir =
          await getTemporaryDirectory();

      audioPath =
          '${dir.path}/audio_${DateTime.now().millisecondsSinceEpoch}.m4a';

      await _recorder.start(
        const RecordConfig(),

        path: audioPath!,
      );

      setState(() {

        isRecording = true;
      });

    } else {

      await _recorder.stop();

      setState(() {

        isRecording = false;

        messages.add({

          'type': 'audio',

          'file': audioPath,

          'isMe': true,
        });
      });

      scrollDown();
    }
  }

  void deleteMessage(
      int index) {

    setState(() {

      messages.removeAt(index);
    });
  }


  void editMessage(
      int index) {

    final l10n =
        AppLocalizations.of(context)!;

    final oldText =
        messages[index]['text'];

    final editController =
        TextEditingController(
      text: oldText,
    );

    showDialog(
      context: context,

      builder: (_) {

        return AlertDialog(
          backgroundColor:
              const Color(
                  0xFF1E1E2D),

          title: Text(
            l10n.chatEditMessageDialogTitle,

            style: const TextStyle(
              color: Colors.white,
            ),
          ),

          content: TextField(
            controller:
                editController,

            style:
                const TextStyle(
              color: Colors.white,
            ),
          ),

          actions: [

            TextButton(
              onPressed: () {

                Navigator.pop(
                    context);
              },

              child:
                  Text(
                l10n.commonCancel,
              ),
            ),

            TextButton(
              onPressed: () {

                setState(() {

                  messages[index]
                          ['text'] =
                      editController
                          .text;
                });

                Navigator.pop(
                    context);
              },

              child:
                  Text(
                l10n.commonSave,
              ),
            ),
          ],
        );
      },
    );
  }

  void forwardMessage(
      Map msg) {

    final l10n =
        AppLocalizations.of(context)!;

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(

      SnackBar(
        content: Text(
          l10n.chatMessageForwardedSnackbar,
        ),
      ),
    );
  }

  void scrollDown() {

    Future.delayed(
      const Duration(
          milliseconds: 100), () {

      if (_scroll.hasClients) {

        _scroll.animateTo(
          _scroll.position
                  .maxScrollExtent +
              200,

          duration:
              const Duration(
            milliseconds: 300,
          ),

          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(
      BuildContext context) {

    final l10n =
        AppLocalizations.of(context)!;

    final accentColor =
        context.watch<ThemeController>().accentColor;

    if (isChatOpen) {

      return Scaffold(
        backgroundColor:
            const Color(
                0xFF0F0F1A),

        appBar: AppBar(
          elevation: 0,

          backgroundColor:
              const Color(
                  0xFF151526),

          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
            ),

            onPressed: () {

              setState(() {

                isChatOpen =
                    false;
              });
            },
          ),

          title: Row(
            children: [

              CircleAvatar(
                radius: 22,

                backgroundColor:
                    accentColor,

                child: const Icon(
                  Icons.person,
                ),
              ),

              const SizedBox(
                  width: 12),

              Column(
                crossAxisAlignment:
                    CrossAxisAlignment
                        .start,

                children: [

                  Text(
                    currentChatName,

                    style:
                        const TextStyle(
                      color:
                          Colors.white,

                      fontWeight:
                          FontWeight
                              .bold,

                      fontSize:
                          18,
                    ),
                  ),

                  Text(
                    l10n.chatOnlineStatusLabel,

                    style: const TextStyle(
                      color:
                          Colors.greenAccent,

                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),

        body: Column(
          children: [

            Expanded(
              child:
                  ListView.builder(
                controller:
                    _scroll,

                padding:
                    const EdgeInsets.all(
                        14),

                itemCount:
                    messages.length,

                itemBuilder:
                    (_, i) {

                  return buildMessage(
                    messages[i],
                    i,
                  );
                },
              ),
            ),

            Container(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 8,
              ),

              decoration:
                  const BoxDecoration(
                color:
                    Color(0xFF151526),
              ),

              child: Row(
                children: [

                  IconButton(
                    icon: const Icon(
                      Icons.image,
                      color:
                          Colors.white70,
                    ),

                    onPressed:
                        pickImage,
                  ),

                  IconButton(
                    icon: const Icon(
                      Icons.videocam,
                      color:
                          Colors.white70,
                    ),

                    onPressed:
                        pickVideo,
                  ),

                  IconButton(
                    icon: const Icon(
                      Icons.attach_file,
                      color:
                          Colors.white70,
                    ),

                    onPressed:
                        pickFile,
                  ),

                  IconButton(
                    icon: Icon(
                      isRecording

                          ? Icons
                              .stop_circle

                          : Icons.mic,

                      color:
                          isRecording

                              ? Colors.red

                              : accentColor,
                    ),

                    onPressed:
                        toggleRecording,
                  ),

                  Expanded(
                    child:
                        Container(
                      padding:
                          const EdgeInsets.symmetric(
                        horizontal: 14,
                      ),

                      decoration:
                          BoxDecoration(
                        color:
                            Colors.white10,

                        borderRadius:
                            BorderRadius.circular(
                                30),
                      ),

                      child:
                          TextField(
                        controller:
                            _controller,

                        style:
                            const TextStyle(
                          color:
                              Colors.white,
                        ),

                        decoration:
                            InputDecoration(
                          hintText:
                              l10n.chatMessageInputHint,

                          hintStyle:
                              const TextStyle(
                            color:
                                Colors.white54,
                          ),

                          border:
                              InputBorder.none,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(
                      width: 8),

                  CircleAvatar(
                    radius: 26,

                    backgroundColor:
                        accentColor,

                    child:
                        IconButton(
                      icon: const Icon(
                        Icons.send,
                        color:
                            Colors.white,
                      ),

                      onPressed:
                          sendText,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor:
          const Color(0xFF0F0F1A),

      appBar: AppBar(
        elevation: 0,

        backgroundColor:
            const Color(
                0xFF151526),

        title: const Text(
          "Zentry",

          style: TextStyle(
            color: Colors.white,
          ),
        ),

        bottom: TabBar(
          controller:
              _tabController,

          indicatorColor:
              accentColor,

          tabs: [

            Tab(
              text: l10n.chatTabChats,
            ),

            Tab(
              text: l10n.chatTabStatuses,
            ),

            Tab(
              text: l10n.chatTabCalls,
            ),
          ],
        ),
      ),

      body: TabBarView(
        controller:
            _tabController,

        children: [

          ListView(
            padding:
                const EdgeInsets.only(
                    top: 10),

            children: [


              const SizedBox(
                  height: 10),

              buildChatTile(
                  "Carlos Ruiz", accentColor),

              buildChatTile(
                  "Ana Torres", accentColor),

              buildChatTile(
                  "María López", accentColor),

              buildChatTile(
                  "Alex Rivera", accentColor),

              buildChatTile(
                  "Fernanda", accentColor),
            ],
          ),

          ListView(
            padding:
                const EdgeInsets.only(
                    top: 10),

            children: [

              ListTile(
                leading: Stack(
                  children: [

                    CircleAvatar(
                      radius: 28,

                      backgroundColor:
                          accentColor,

                      child: const Icon(
                        Icons.person,
                        color:
                            Colors.white,
                      ),
                    ),

                    Positioned(
                      bottom: 0,
                      right: 0,

                      child:
                          Container(
                        width: 20,
                        height: 20,

                        decoration:
                            const BoxDecoration(
                          color:
                              Colors.greenAccent,

                          shape:
                              BoxShape.circle,
                        ),

                        child:
                            const Icon(
                          Icons.add,

                          size: 16,

                          color:
                              Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),

                title: Text(
                  l10n.chatMyStatusTitle,

                  style: const TextStyle(
                    color:
                        Colors.white,

                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                subtitle: Text(
                  l10n.chatMyStatusSubtitle,

                  style: const TextStyle(
                    color:
                        Colors.white54,
                  ),
                ),
              ),

              Padding(
                padding:
                    const EdgeInsets.only(
                  left: 18,
                  top: 10,
                  bottom: 10,
                ),

                child: Text(
                  l10n.chatRecentSectionTitle,

                  style: const TextStyle(
                    color:
                        Colors.white54,

                    fontWeight:
                        FontWeight.w600,
                  ),
                ),
              ),

              buildEstadoTile(
                "Carlos Ruiz",
                "Hace 10 minutos",
              ),

              buildEstadoTile(
                "Ana Torres",
                "Hace 25 minutos",
              ),

              buildEstadoTile(
                "María López",
                "Hace 1 hora",
              ),
            ],
          ),

          ListView(
            padding:
                const EdgeInsets.only(
                    top: 10),

            children: [

              buildCallTile(
                "Carlos Ruiz",
                true,
                accentColor,
              ),

              buildCallTile(
                "Ana Torres",
                false,
                accentColor,
              ),

              buildCallTile(
                "María López",
                true,
                accentColor,
              ),

              buildCallTile(
                "Alex Rivera",
                false,
                accentColor,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildChatTile(
      String name,
      Color accentColor) {

    return ListTile(
      leading:
          CircleAvatar(
        backgroundColor:
            accentColor,

        child:
            const Icon(Icons.person),
      ),

      title: Text(
        name,

        style:
            const TextStyle(
          color: Colors.white,
        ),
      ),

      subtitle: const Text(
        "Último mensaje...",

        style: TextStyle(
          color: Colors.white54,
        ),
      ),

      trailing: const Text(
        "23:22",

        style: TextStyle(
          color:
              Colors.white70,

          fontSize: 12,

          fontWeight:
              FontWeight.w500,
        ),
      ),

      onTap: () =>
          openChat(name),
    );
  }

  Widget buildEstadoTile(
    String name,
    String time,
  ) {

    return ListTile(
      leading: Container(
        padding:
            const EdgeInsets.all(
                3),

        decoration:
            BoxDecoration(
          shape:
              BoxShape.circle,

          gradient:
              const LinearGradient(
            colors: [

              Color(0xFF8B5CF6),
              Color(0xFFD946EF),
            ],
          ),
        ),

        child:
            const CircleAvatar(
          radius: 26,

          backgroundColor:
              Color(0xFF1E1E2D),

          child: Icon(
            Icons.person,
            color: Colors.white,
          ),
        ),
      ),

      title: Text(
        name,

        style:
            const TextStyle(
          color: Colors.white,

          fontWeight:
              FontWeight.w600,
        ),
      ),

      subtitle: Text(
        time,

        style:
            const TextStyle(
          color:
              Colors.white54,
        ),
      ),
    );
  }

  Widget buildCallTile(
    String name,
    bool incoming,
    Color accentColor,
  ) {

    final l10n =
        AppLocalizations.of(context)!;

    return ListTile(
      leading:
          CircleAvatar(
        radius: 26,

        backgroundColor:
            accentColor,

        child: const Icon(
          Icons.person,
          color: Colors.white,
        ),
      ),

      title: Text(
        name,

        style:
            const TextStyle(
          color: Colors.white,

          fontWeight:
              FontWeight.w600,
        ),
      ),

      subtitle: Row(
        children: [

          Icon(
            incoming

                ? Icons.call_received

                : Icons.call_made,

            color:
                incoming

                    ? Colors.greenAccent

                    : Colors.redAccent,

            size: 18,
          ),

          const SizedBox(
              width: 6),

          Text(
            incoming

                ? l10n.chatIncomingCallLabel

                : l10n.chatMissedCallLabel,

            style:
                const TextStyle(
              color:
                  Colors.white54,
            ),
          ),
        ],
      ),

      trailing: Container(
        width: 42,
        height: 42,

        decoration:
            BoxDecoration(
          color:
              Colors.white10,

          borderRadius:
              BorderRadius.circular(
                  14),
        ),

        child: IconButton(
          onPressed: () {},

          icon: Icon(
            Icons.call,

            color:
                accentColor,

            size: 20,
          ),
        ),
      ),
    );
  }

  Widget buildMessage(
    Map msg,
    int index,
  ) {

    final l10n =
        AppLocalizations.of(context)!;

    Widget content;

    switch (msg['type']) {

      case 'media_group':

        content =
            MediaGridWidget(
          files:
              List<File>.from(
            msg['files'],
          ),

          isVideo:
              msg['mediaType'] ==
                  'video',
        );

        break;

      case 'file':

        final file =
            msg['file'];

        content =
            GestureDetector(
          onTap: () async {

            await OpenFilex.open(
              file.path,
            );
          },

          child: Container(
            width: 240,

            padding:
                const EdgeInsets.all(
                    14),

            decoration:
                BoxDecoration(
              color:
                  Colors.white10,

              borderRadius:
                  BorderRadius.circular(
                      18),
            ),

            child: Row(
              children: [

                Container(
                  width: 52,
                  height: 52,

                  decoration:
                      BoxDecoration(
                    color: Colors.red,

                    borderRadius:
                        BorderRadius.circular(
                            14),
                  ),

                  child:
                      const Icon(
                    Icons.picture_as_pdf,

                    color:
                        Colors.white,

                    size: 28,
                  ),
                ),

                const SizedBox(
                    width: 12),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment
                            .start,

                    children: [

                      Text(
                        msg['name'],

                        maxLines: 2,

                        overflow:
                            TextOverflow
                                .ellipsis,

                        style:
                            const TextStyle(
                          color:
                              Colors.white,

                          fontWeight:
                              FontWeight
                                  .w600,
                        ),
                      ),

                      const SizedBox(
                          height: 5),

                      Text(
                        "${(msg['size'] / 1024).toStringAsFixed(1)} KB",

                        style:
                            const TextStyle(
                          color:
                              Colors.white54,

                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );

        break;

      case 'audio':

        content =
            AudioBubble(
          filePath:
              msg['file'],
        );

        break;

      default:

        content = Text(
          msg['text'],

          style:
              const TextStyle(
            color: Colors.white,
            fontSize: 15,
          ),
        );
    }

    return GestureDetector(
      onLongPress: () {

        showModalBottomSheet(
          context: context,

          backgroundColor:
              const Color(
                  0xFF1E1E2D),

          builder: (_) {

            return SafeArea(
              child: Wrap(
                children: [

                  if (msg['type'] ==
                      'text')

                    ListTile(
                      leading:
                          const Icon(
                        Icons.edit,
                        color:
                            Colors.white,
                      ),

                      title:
                          Text(
                        l10n.commonEdit,

                        style:
                            const TextStyle(
                          color:
                              Colors.white,
                        ),
                      ),

                      onTap: () {

                        Navigator.pop(
                            context);

                        editMessage(
                            index);
                      },
                    ),

                  ListTile(
                    leading:
                        const Icon(
                      Icons.forward,
                      color:
                          Colors.white,
                    ),

                    title:
                        Text(
                      l10n.chatForwardActionLabel,

                      style:
                          const TextStyle(
                        color:
                            Colors.white,
                      ),
                    ),

                    onTap: () {

                      Navigator.pop(
                          context);

                      forwardMessage(
                          msg);
                    },
                  ),

                  ListTile(
                    leading:
                        const Icon(
                      Icons.delete,
                      color: Colors.red,
                    ),

                    title:
                        Text(
                      l10n.commonDelete,

                      style:
                          const TextStyle(
                        color: Colors.red,
                      ),
                    ),

                    onTap: () {

                      Navigator.pop(
                          context);

                      deleteMessage(
                          index);
                    },
                  ),
                ],
              ),
            );
          },
        );
      },

      child: Align(
        alignment:
            msg['isMe']

                ? Alignment
                    .centerRight

                : Alignment
                    .centerLeft,

        child: Container(
          margin:
              const EdgeInsets.symmetric(
            vertical: 6,
          ),

          padding:
              const EdgeInsets.all(
                  10),

          decoration:
              BoxDecoration(
            color: msg['isMe']

                ? const Color(
                    0xFF2B2B3D)

                : const Color(
                    0xFF1E1E2D),

            borderRadius:
                BorderRadius.circular(
                    20),
          ),

          child: content,
        ),
      ),
    );
  }
}

class AudioBubble
    extends StatefulWidget {

  final String filePath;

  const AudioBubble({
    super.key,

    required this.filePath,
  });

  @override
  State<AudioBubble>
      createState() =>
          _AudioBubbleState();
}

class _AudioBubbleState
    extends State<AudioBubble> {

  final AudioPlayer player =
      AudioPlayer();

  bool isPlaying = false;

  Duration duration =
      Duration.zero;

  Duration position =
      Duration.zero;

  @override
  void initState() {

    super.initState();

    initAudio();
  }

  Future<void> initAudio()
  async {

    await player.setFilePath(
      widget.filePath,
    );

    duration =
        player.duration ??
            Duration.zero;

    player.positionStream
        .listen((p) {

      setState(() {

        position = p;
      });
    });

    player.playerStateStream
        .listen((state) {

      setState(() {

        isPlaying =
            state.playing;
      });
    });
  }

  String format(
      Duration d) {

    final min =
        d.inMinutes
            .remainder(60)
            .toString()
            .padLeft(2, '0');

    final sec =
        d.inSeconds
            .remainder(60)
            .toString()
            .padLeft(2, '0');

    return "$min:$sec";
  }

  @override
  Widget build(
      BuildContext context) {

    final accentColor =
        context.watch<ThemeController>().accentColor;

    return Container(
      width: 250,

      padding:
          const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 10,
      ),

      decoration:
          BoxDecoration(
        gradient:
            LinearGradient(
          colors: [

            accentColor
                .withOpacity(0.9),

            const Color(
                0xFF7C3AED),
          ],
        ),

        borderRadius:
            BorderRadius.circular(
                22),
      ),

      child: Row(
        children: [

          GestureDetector(
            onTap: () async {

              if (isPlaying) {

                await player.pause();

              } else {

                await player.play();
              }
            },

            child: Container(
              width: 46,
              height: 46,

              decoration:
                  BoxDecoration(
                color:
                    Colors.white
                        .withOpacity(
                            0.15),

                shape:
                    BoxShape.circle,
              ),

              child: Icon(
                isPlaying

                    ? Icons.pause

                    : Icons.play_arrow,

                color:
                    Colors.white,
              ),
            ),
          ),

          const SizedBox(
              width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment
                      .start,

              children: [

                SliderTheme(
                  data:
                      SliderTheme.of(
                              context)
                          .copyWith(
                    trackHeight: 2,

                    thumbShape:
                        const RoundSliderThumbShape(
                      enabledThumbRadius:
                          5,
                    ),

                    overlayShape:
                        SliderComponentShape
                            .noOverlay,
                  ),

                  child: Slider(
                    activeColor:
                        Colors.white,

                    inactiveColor:
                        Colors.white24,

                    min: 0,

                    max: duration
                        .inMilliseconds
                        .toDouble(),

                    value: position
                        .inMilliseconds
                        .toDouble()
                        .clamp(
                          0,
                          duration
                              .inMilliseconds
                              .toDouble(),
                        ),

                    onChanged:
                        (value)
                        async {

                      await player.seek(
                        Duration(
                          milliseconds:
                              value
                                  .toInt(),
                        ),
                      );
                    },
                  ),
                ),

                Row(
                  mainAxisAlignment:
                      MainAxisAlignment
                          .spaceBetween,

                  children: [

                    Text(
                      format(position),

                      style:
                          const TextStyle(
                        color:
                            Colors.white70,

                        fontSize:
                            11,
                      ),
                    ),

                    Text(
                      format(duration),

                      style:
                          const TextStyle(
                        color:
                            Colors.white70,

                        fontSize:
                            11,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {

    player.dispose();

    super.dispose();
  }
}