import 'package:Zentry/features/profile/profile_menu_screen.dart';
import 'package:Zentry/theme/theme_controller.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Map<String, dynamic>> posts = [
    {
      "user": "Luis Martínez",
      "category": "Programación",
      "time": "Hace 5 min",

      "image": "https://images.unsplash.com/photo-1515879218367-8466d910aaa4",

      "content": "Desarrollando nuevas funciones para Zentry 🚀",

      "likes": 124,
    },

    {
      "user": "Ana Torres",
      "category": "Arte Digital",
      "time": "Hace 12 min",

      "image": "https://images.unsplash.com/photo-1513364776144-60967b0f800f",

      "content": "Nueva ilustración inspirada en cyberpunk ✨",

      "likes": 312,
    },

    {
      "user": "Carlos Ruiz",
      "category": "GameDev",
      "time": "Hace 18 min",

      "image": "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8",

      "content": "Probando físicas nuevas en Unity 🎮",

      "likes": 220,
    },

    {
      "user": "María López",
      "category": "Fotografía",
      "time": "Hace 30 min",

      "image": "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4",

      "content": "Capturando momentos urbanos 📸",

      "likes": 98,
    },

    {
      "user": "Alex Rivera",
      "category": "Música",
      "time": "Hace 1 hora",

      "image": "https://images.unsplash.com/photo-1511379938547-c1f69419868d",

      "content": "Trabajando en un nuevo beat 🎧",

      "likes": 441,
    },

    {
      "user": "Fernanda",
      "category": "Diseño UI",
      "time": "Hace 2 horas",

      "image": "https://images.unsplash.com/photo-1558655146-d09347e92766",

      "content": "Experimentando nuevos estilos minimalistas.",

      "likes": 189,
    },

    {
      "user": "Daniel Vega",
      "category": "Animación",
      "time": "Hace 3 horas",

      "image": "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d",

      "content": "Render final listo 🔥",

      "likes": 274,
    },

    {
      "user": "Valeria Cruz",
      "category": "PixelArt",
      "time": "Hace 4 horas",

      "image": "https://images.unsplash.com/photo-1545239351-1141bd82e8a6",

      "content": "Diseñando escenarios retro 👾",

      "likes": 165,
    },

    {
      "user": "Diego León",
      "category": "Escritura",
      "time": "Hace 5 horas",

      "image": "https://images.unsplash.com/photo-1455390582262-044cdead277a",

      "content": "Nuevo capítulo terminado ✍️",

      "likes": 76,
    },

    {
      "user": "Sofía Morales",
      "category": "Video",
      "time": "Hace 6 horas",

      "image": "https://images.unsplash.com/photo-1492619375914-88005aa9e8fb",

      "content": "Editando cinematicas para un corto 🎬",

      "likes": 530,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final accentColor = context.watch<ThemeController>().accentColor;

    return Scaffold(
      backgroundColor: const Color(0xFF09090F),

      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),

          slivers: [
            /// HEADER
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(18),

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: [
                    const Text(
                      "Zentry",

                      style: TextStyle(
                        color: Colors.white,

                        fontSize: 30,

                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    Row(
                      children: [
                        IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.search, color: Colors.white),
                        ),

                        IconButton(
                          onPressed: () {},
                          icon: const Icon(
                            Icons.notifications_none,
                            color: Colors.white,
                          ),
                        ),

                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const ProfileMenuScreen(),
                              ),
                            );
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(left: 8),
                            child: CircleAvatar(
                              radius: 18,
                              backgroundColor: accentColor,
                              child: Icon(Icons.person, color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            /// STORIES
            SliverToBoxAdapter(
              child: SizedBox(
                height: 110,

                child: ListView.builder(
                  scrollDirection: Axis.horizontal,

                  padding: const EdgeInsets.symmetric(horizontal: 14),

                  itemCount: 10,

                  itemBuilder: (_, index) {
                    return Container(
                      width: 78,

                      margin: const EdgeInsets.only(right: 12),

                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(3),

                            decoration: BoxDecoration(
                              shape: BoxShape.circle,

                              gradient: const LinearGradient(
                                colors: [Color(0xFF8B5CF6), Color(0xFFD946EF)],
                              ),
                            ),

                            child: CircleAvatar(
                              radius: 30,

                              backgroundImage: NetworkImage(
                                "https://i.pravatar.cc/300?img=${index + 10}",
                              ),
                            ),
                          ),

                          const SizedBox(height: 6),

                          Text(
                            posts[index]["user"],

                            style: const TextStyle(
                              color: Colors.white,

                              fontSize: 12,
                            ),

                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),

            /// POSTS
            SliverList(
              delegate: SliverChildBuilderDelegate((_, index) {
                final post = posts[index];

                return Container(
                  margin: const EdgeInsets.only(
                    left: 14,
                    right: 14,
                    bottom: 18,
                  ),

                  padding: const EdgeInsets.all(14),

                  decoration: BoxDecoration(
                    color: const Color(0xFF141420),

                    borderRadius: BorderRadius.circular(26),
                  ),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      /// USER
                      Row(
                        children: [
                          CircleAvatar(
                            radius: 22,

                            backgroundImage: NetworkImage(
                              "https://i.pravatar.cc/300?img=${index + 1}",
                            ),
                          ),

                          const SizedBox(width: 12),

                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,

                              children: [
                                Text(
                                  post["user"],

                                  style: const TextStyle(
                                    color: Colors.white,

                                    fontWeight: FontWeight.bold,

                                    fontSize: 16,
                                  ),
                                ),

                                Text(
                                  "${post["category"]} • ${post["time"]}",

                                  style: const TextStyle(
                                    color: Colors.white54,

                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          IconButton(
                            onPressed: () {},

                            icon: const Icon(
                              Icons.more_horiz,

                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 14),

                      /// TEXTO
                      Text(
                        post["content"],

                        style: const TextStyle(
                          color: Colors.white,

                          fontSize: 15,

                          height: 1.4,
                        ),
                      ),

                      const SizedBox(height: 14),

                      /// IMAGEN
                      ClipRRect(
                        borderRadius: BorderRadius.circular(22),

                        child: Image.network(
                          post["image"],

                          height: 240,

                          width: double.infinity,

                          fit: BoxFit.cover,

                          loadingBuilder: (context, child, progress) {
                            if (progress == null) {
                              return child;
                            }

                            return Container(
                              height: 240,

                              color: Colors.white10,

                              child: Center(
                                child: CircularProgressIndicator(
                                  color: accentColor,
                                ),
                              ),
                            );
                          },
                        ),
                      ),

                      const SizedBox(height: 16),

                      /// ACCIONES
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,

                        children: [
                          /// LIKE
                          AnimatedLikeButton(likes: post["likes"]),
                          const AnimatedActionButton(
                            icon: Icons.mode_comment_outlined,
                          ),

                          /// SHARE
                          const AnimatedActionButton(
                            icon: Icons.share_outlined,
                          ),

                          /// SAVE
                          const AnimatedActionButton(
                            icon: Icons.bookmark_border,
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              }, childCount: posts.length),
            ),
          ],
        ),
      ),
    );
  }
}

/// =======================================
/// BOTÓN LIKE ANIMADO
/// =======================================
class AnimatedLikeButton extends StatefulWidget {
  final int likes;

  const AnimatedLikeButton({super.key, required this.likes});

  @override
  State<AnimatedLikeButton> createState() => _AnimatedLikeButtonState();
}

class _AnimatedLikeButtonState extends State<AnimatedLikeButton> {
  bool liked = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          liked = !liked;
        });
      },

      child: AnimatedScale(
        scale: liked ? 1.2 : 1,

        duration: const Duration(milliseconds: 180),

        child: Row(
          children: [
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),

              transitionBuilder: (child, animation) {
                return ScaleTransition(scale: animation, child: child);
              },

              child: Icon(
                liked ? Icons.favorite : Icons.favorite_border,

                key: ValueKey(liked),

                color: liked ? Colors.pinkAccent : Colors.white70,

                size: 22,
              ),
            ),

            const SizedBox(width: 6),

            Text(
              liked ? "${widget.likes + 1}" : "${widget.likes}",

              style: const TextStyle(color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}

/// =======================================
/// BOTÓN SIMPLE ANIMADO
/// =======================================
class AnimatedActionButton extends StatefulWidget {
  final IconData icon;

  const AnimatedActionButton({super.key, required this.icon});

  @override
  State<AnimatedActionButton> createState() => _AnimatedActionButtonState();
}

class _AnimatedActionButtonState extends State<AnimatedActionButton> {
  bool pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        setState(() {
          pressed = true;
        });
      },

      onTapUp: (_) {
        setState(() {
          pressed = false;
        });
      },

      onTapCancel: () {
        setState(() {
          pressed = false;
        });
      },

      child: AnimatedScale(
        scale: pressed ? 0.82 : 1,

        duration: const Duration(milliseconds: 120),

        child: Icon(widget.icon, color: Colors.white70, size: 23),
      ),
    );
  }
}
