import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:Zentry/l10n/generated/app_localizations.dart';
import 'package:Zentry/theme/theme_controller.dart';

class CommunitiesScreen extends StatefulWidget {
  const CommunitiesScreen({super.key});

  @override
  State<CommunitiesScreen> createState() => _CommunitiesScreenState();
}

class _CommunitiesScreenState extends State<CommunitiesScreen>
    with TickerProviderStateMixin {
  late AnimationController animationController;

  final ScrollController scrollController = ScrollController();

  final TextEditingController searchController = TextEditingController();

  bool searching = false;

  int selectedCategory = 0;

  final List<String> categories = [
    "Todas",

    "Arte",

    "Programación",

    "Música",

    "Videojuegos",

    "Literatura",

    "Cine",
  ];

  final List<Map<String, dynamic>> communities = [
    {
      "name": "Arte Digital",

      "category": "Arte",

      "members": "15.2K",

      "description": "Comparte ilustraciones, diseño y arte conceptual.",

      "cover": "assets/inicio.png",

      "verified": true,

      "joined": false,

      "trending": true,
    },

    {
      "name": "Flutter Dev",

      "category": "Programación",

      "members": "9.4K",

      "description": "Desarrollo móvil con Flutter y Dart.",

      "cover": "assets/login.png",

      "verified": true,

      "joined": true,

      "trending": true,
    },

    {
      "name": "Música",

      "category": "Música",

      "members": "8.1K",

      "description": "Comparte tus composiciones y descubre nuevos artistas.",

      "cover": "assets/inicio.png",

      "verified": false,

      "joined": false,

      "trending": false,
    },

    {
      "name": "Gaming Zone",

      "category": "Videojuegos",

      "members": "12.7K",

      "description": "Noticias, clips y torneos.",

      "cover": "assets/login.png",

      "verified": false,

      "joined": true,

      "trending": true,
    },

    {
      "name": "Escritores",

      "category": "Literatura",

      "members": "5.6K",

      "description": "Historias, novelas y poesía.",

      "cover": "assets/inicio.png",

      "verified": true,

      "joined": false,

      "trending": false,
    },
  ];

  late List<Map<String, dynamic>> filteredCommunities;

  @override
  void initState() {
    super.initState();

    filteredCommunities = List.from(communities);

    animationController = AnimationController(
      vsync: this,

      duration: const Duration(milliseconds: 700),
    );

    animationController.forward();

    searchController.addListener(filterCommunities);
  }

  @override
  void dispose() {
    animationController.dispose();

    scrollController.dispose();

    searchController.dispose();

    super.dispose();
  }

  Future<void> refresh() async {
    await Future.delayed(const Duration(seconds: 1));

    filterCommunities();
  }

  void filterCommunities() {
    String query = searchController.text.toLowerCase();

    setState(() {
      filteredCommunities = communities.where((community) {
        bool matchesSearch =
            community["name"].toLowerCase().contains(query) ||
            community["description"].toLowerCase().contains(query);

        if (selectedCategory == 0) {
          return matchesSearch;
        }

        return matchesSearch &&
            community["category"] == categories[selectedCategory];
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final accentColor = context.watch<ThemeController>().accentColor;
    return Scaffold(
      backgroundColor: const Color(0xff09090F),

      appBar: AppBar(
        elevation: 0,

        backgroundColor: const Color(0xff09090F),

        title: Text(
          l10n.communitiesScreenTitle,

          style: const TextStyle(fontWeight: FontWeight.bold),
        ),

        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                searching = !searching;
              });
            },

            icon: Icon(searching ? Icons.close : Icons.search),
          ),

          IconButton(onPressed: () {}, icon: const Icon(Icons.groups_rounded)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: refresh,

        child: ListView(
          controller: scrollController,

          padding: const EdgeInsets.all(18),

          children: [
            FadeTransition(
              opacity: animationController,

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [
                  Text(
                    l10n.communitiesHeading,

                    style: const TextStyle(
                      color: Colors.white,

                      fontSize: 28,

                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 8),

                  Text(
                    l10n.communitiesSubtitle,

                    style: TextStyle(color: Colors.grey.shade500, fontSize: 14),
                  ),

                  const SizedBox(height: 25),

                  Row(
                    children: [
                      Expanded(
                        child: _statCard(
                          Icons.groups,

                          Colors.blue,

                          communities.length.toString(),

                          l10n.communitiesStatCommunities,
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: _statCard(
                          Icons.local_fire_department,

                          Colors.orange,

                          communities
                              .where((e) => e["trending"])
                              .length
                              .toString(),

                          l10n.communitiesStatTrending,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  Row(
                    children: [
                      Expanded(
                        child: _statCard(
                          Icons.verified,

                          Colors.lightBlue,

                          communities
                              .where((e) => e["verified"])
                              .length
                              .toString(),

                          l10n.communitiesStatVerified,
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: _statCard(
                          Icons.person,

                          Colors.green,

                          communities
                              .where((e) => e["joined"])
                              .length
                              .toString(),

                          l10n.communitiesStatMine,
                        ),
                      ),
                    ],
                  ),

                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),

                    height: searching ? 65 : 0,

                    margin: EdgeInsets.only(top: searching ? 25 : 0),

                    child: TextField(
                      controller: searchController,

                      style: const TextStyle(color: Colors.white),

                      decoration: InputDecoration(
                        filled: true,

                        fillColor: const Color(0xff171725),

                        hintText: l10n.communitiesSearchHint,

                        hintStyle: TextStyle(color: Colors.grey.shade500),

                        prefixIcon: const Icon(
                          Icons.search,

                          color: Colors.white70,
                        ),

                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),

                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  SizedBox(
                    height: 42,

                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,

                      itemCount: categories.length,

                      itemBuilder: (_, index) {
                        bool selected = selectedCategory == index;

                        return Padding(
                          padding: const EdgeInsets.only(right: 10),

                          child: ChoiceChip(
                            label: Text(categories[index]),

                            selected: selected,

                            backgroundColor: const Color(0xff171725),

                            selectedColor: accentColor,

                            labelStyle: TextStyle(
                              color: selected
                                  ? Colors.white
                                  : Colors.grey.shade400,
                            ),

                            onSelected: (_) {
                              setState(() {
                                selectedCategory = index;

                                filterCommunities();
                              });
                            },
                          ),
                        );
                      },
                    ),
                  ),

                  const SizedBox(height: 25),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: [
                      Text(
                        l10n.communitiesFeaturedTitle,

                        style: const TextStyle(
                          color: Colors.white,

                          fontSize: 18,

                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      TextButton(
                        onPressed: () {},

                        child: Text(l10n.communitiesSeeAll),
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),
                  if (filteredCommunities.isEmpty)
                    _emptyState(l10n)
                  else
                    GridView.builder(
                      shrinkWrap: true,

                      physics: const NeverScrollableScrollPhysics(),

                      itemCount: filteredCommunities.length,

                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,

                            crossAxisSpacing: 15,

                            mainAxisSpacing: 15,

                            childAspectRatio: .74,
                          ),

                      itemBuilder: (_, index) {
                        final community = filteredCommunities[index];

                        return TweenAnimationBuilder<double>(
                          duration: Duration(milliseconds: 250 + (index * 80)),

                          tween: Tween(begin: .90, end: 1),

                          curve: Curves.easeOutBack,

                          builder: (_, value, child) {
                            return Transform.scale(scale: value, child: child);
                          },

                          child: GestureDetector(
                            onTap: () {
                              // TODO:
                              // Abrir comunidad
                            },

                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(0xff171725),

                                borderRadius: BorderRadius.circular(22),

                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(.25),

                                    blurRadius: 15,

                                    offset: const Offset(0, 8),
                                  ),
                                ],
                              ),

                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,

                                children: [
                                  Expanded(
                                    flex: 6,

                                    child: Hero(
                                      tag: "community_$index",

                                      child: ClipRRect(
                                        borderRadius: const BorderRadius.only(
                                          topLeft: Radius.circular(22),

                                          topRight: Radius.circular(22),
                                        ),

                                        child: Stack(
                                          children: [
                                            Positioned.fill(
                                              child: Image.asset(
                                                community["cover"],

                                                fit: BoxFit.cover,
                                              ),
                                            ),

                                            Positioned(
                                              top: 10,

                                              left: 10,

                                              child: Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                      horizontal: 10,

                                                      vertical: 5,
                                                    ),

                                                decoration: BoxDecoration(
                                                  color: accentColor,

                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                ),

                                                child: Text(
                                                  community["category"],

                                                  style: const TextStyle(
                                                    color: Colors.white,

                                                    fontSize: 11,

                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                            ),

                                            if (community["verified"])
                                              const Positioned(
                                                top: 10,

                                                right: 10,

                                                child: Icon(
                                                  Icons.verified,

                                                  color: Colors.lightBlue,

                                                  size: 22,
                                                ),
                                              ),

                                            if (community["trending"])
                                              Positioned(
                                                right: 10,

                                                bottom: 10,

                                                child: Container(
                                                  padding:
                                                      const EdgeInsets.symmetric(
                                                        horizontal: 10,

                                                        vertical: 5,
                                                      ),

                                                  decoration: BoxDecoration(
                                                    color: Colors.orange,

                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          20,
                                                        ),
                                                  ),

                                                  child: Row(
                                                    children: [
                                                      const Icon(
                                                        Icons
                                                            .local_fire_department,

                                                        color: Colors.white,

                                                        size: 14,
                                                      ),

                                                      const SizedBox(width: 4),

                                                      Text(
                                                        l10n.communitiesHotBadge,

                                                        style: const TextStyle(
                                                          color: Colors.white,

                                                          fontWeight:
                                                              FontWeight.bold,

                                                          fontSize: 10,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),

                                  Expanded(
                                    flex: 4,

                                    child: Padding(
                                      padding: const EdgeInsets.all(12),

                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,

                                        children: [
                                          Text(
                                            community["name"],

                                            maxLines: 1,

                                            overflow: TextOverflow.ellipsis,

                                            style: const TextStyle(
                                              color: Colors.white,

                                              fontWeight: FontWeight.bold,

                                              fontSize: 16,
                                            ),
                                          ),

                                          const SizedBox(height: 4),

                                          Text(
                                            community["description"],

                                            maxLines: 2,

                                            overflow: TextOverflow.ellipsis,

                                            style: TextStyle(
                                              color: Colors.grey.shade400,

                                              fontSize: 12,
                                            ),
                                          ),

                                          const Spacer(),

                                          Row(
                                            children: [
                                              Icon(
                                                Icons.groups,

                                                size: 15,

                                                color: Colors.grey.shade500,
                                              ),

                                              const SizedBox(width: 4),

                                              Text(
                                                community["members"],

                                                style: TextStyle(
                                                  color: Colors.grey.shade400,

                                                  fontSize: 11,
                                                ),
                                              ),

                                              const Spacer(),

                                              SizedBox(
                                                height: 32,

                                                child: ElevatedButton(
                                                  style: ElevatedButton.styleFrom(
                                                    backgroundColor:
                                                        community["joined"]
                                                        ? Colors.green
                                                        : accentColor,

                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                          horizontal: 12,
                                                        ),

                                                    shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            12,
                                                          ),
                                                    ),
                                                  ),

                                                  onPressed: () {
                                                    setState(() {
                                                      community["joined"] =
                                                          !community["joined"];
                                                    });
                                                  },

                                                  child: Text(
                                                    community["joined"]
                                                        ? l10n.communitiesMemberLabel
                                                        : l10n.communitiesJoinLabel,

                                                    style: const TextStyle(
                                                      color: Colors.white,

                                                      fontSize: 11,

                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: accentColor,

        elevation: 8,

        onPressed: () {
          scrollController.animateTo(
            0,

            duration: const Duration(milliseconds: 500),

            curve: Curves.easeOut,
          );
        },

        child: const Icon(Icons.keyboard_arrow_up),
      ),
    );
  }

  Widget _statCard(IconData icon, Color color, String value, String title) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18),

      decoration: BoxDecoration(
        color: const Color(0xff171725),

        borderRadius: BorderRadius.circular(20),
      ),

      child: Column(
        children: [
          Icon(icon, color: color, size: 28),

          const SizedBox(height: 10),

          Text(
            value,

            style: const TextStyle(
              color: Colors.white,

              fontWeight: FontWeight.bold,

              fontSize: 18,
            ),
          ),

          const SizedBox(height: 5),

          Text(
            title,

            style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _emptyState(AppLocalizations l10n) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 80),

      child: Center(
        child: Column(
          children: [
            Icon(Icons.groups_outlined, color: Colors.grey.shade700, size: 72),

            const SizedBox(height: 20),

            Text(
              l10n.communitiesEmptyTitle,

              style: const TextStyle(
                color: Colors.white,

                fontSize: 22,

                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              l10n.communitiesEmptySubtitle,

              textAlign: TextAlign.center,

              style: TextStyle(color: Colors.grey.shade500, fontSize: 14),
            ),

            const SizedBox(height: 25),

            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: accentColor,

                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),

              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(l10n.communitiesExploringSnackbar),
                  ),
                );
              },

              icon: const Icon(Icons.explore),

              label: Text(l10n.communitiesExploreButton),
            ),
          ],
        ),
      ),
    );
  }
}
