import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:Zentry/l10n/generated/app_localizations.dart';
import 'package:Zentry/theme/theme_controller.dart';

class FriendsScreen extends StatefulWidget {
  const FriendsScreen({super.key});

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen>
    with TickerProviderStateMixin {
  late AnimationController animationController;

  final ScrollController scrollController = ScrollController();

  final TextEditingController searchController = TextEditingController();

  bool searching = false;

  int selectedTab = 0;

  List<String> _buildTabs(AppLocalizations l10n) {
    return [
      l10n.chatOnlineStatusLabel,
      l10n.friendsTabRequests,
      l10n.friendsStatFavoritesLabel,
      l10n.eventsFilterAll,
    ];
  }

  final List<Map<String, dynamic>> friends = [
    {
      "name": "Jennifer",

      "username": "@jennifer",

      "status": "En línea",

      "avatar": "assets/login.png",

      "followers": "3.2K",

      "verified": true,

      "favorite": true,

      "online": true,
    },

    {
      "name": "Joseph",

      "username": "@joseph",

      "status": "Hace 5 min",

      "avatar": "assets/inicio.png",

      "followers": "1.8K",

      "verified": false,

      "favorite": false,

      "online": false,
    },

    {
      "name": "Daniel",

      "username": "@daniel",

      "status": "En línea",

      "avatar": "assets/login.png",

      "followers": "980",

      "verified": true,

      "favorite": false,

      "online": true,
    },

    {
      "name": "Andrea",

      "username": "@andrea",

      "status": "Hace 1 h",

      "avatar": "assets/inicio.png",

      "followers": "7.4K",

      "verified": true,

      "favorite": true,

      "online": false,
    },

    {
      "name": "Carlos",

      "username": "@carlos",

      "status": "En línea",

      "avatar": "assets/login.png",

      "followers": "530",

      "verified": false,

      "favorite": false,

      "online": true,
    },
  ];

  late List<Map<String, dynamic>> filteredFriends;

  @override
  void initState() {
    super.initState();

    filteredFriends = List.from(friends);

    animationController = AnimationController(
      vsync: this,

      duration: const Duration(milliseconds: 700),
    );

    animationController.forward();

    searchController.addListener(filterFriends);
  }

  @override
  void dispose() {
    animationController.dispose();

    searchController.dispose();

    scrollController.dispose();

    super.dispose();
  }

  Future<void> refresh() async {
    await Future.delayed(const Duration(seconds: 1));

    filterFriends();
  }

  void filterFriends() {
    String query = searchController.text.toLowerCase();

    setState(() {
      filteredFriends = friends.where((friend) {
        bool matchesSearch =
            friend["name"].toLowerCase().contains(query) ||
            friend["username"].toLowerCase().contains(query);

        switch (selectedTab) {
          case 0:
            return matchesSearch && friend["online"];

          case 1:
            return false;

          case 2:
            return matchesSearch && friend["favorite"];

          default:
            return matchesSearch;
        }
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final tabs = _buildTabs(l10n);
    final accentColor = context.watch<ThemeController>().accentColor;
    return Scaffold(
      backgroundColor: const Color(0xff09090F),

      appBar: AppBar(
        elevation: 0,

        backgroundColor: const Color(0xff09090F),

        title: Text(
          l10n.friendsScreenTitle,

          style: const TextStyle(fontWeight: FontWeight.bold),
        ),

        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                searching = !searching;
              });
            },

            icon: Icon(searching ? Icons.close : Icons.search),
          ),

          IconButton(
            onPressed: () {},

            icon: const Icon(Icons.person_add_alt_1),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: refresh,

        child: ListView(
          controller: scrollController,

          padding: const EdgeInsets.all(18),

          children: [
            FadeTransition(
              opacity: animationController,

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [
                  Text(
                    l10n.friendsHeading,

                    style: const TextStyle(
                      color: Colors.white,

                      fontSize: 28,

                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 8),

                  Text(
                    l10n.friendsSubtitle,

                    style: TextStyle(color: Colors.grey.shade500, fontSize: 14),
                  ),

                  const SizedBox(height: 25),

                  Row(
                    children: [
                      Expanded(
                        child: _statCard(
                          Icons.people,

                          Colors.blue,

                          friends.length.toString(),

                          l10n.friendsScreenTitle,
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: _statCard(
                          Icons.circle,

                          Colors.green,

                          friends.where((e) => e["online"]).length.toString(),

                          l10n.chatOnlineStatusLabel,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  Row(
                    children: [
                      Expanded(
                        child: _statCard(
                          Icons.star,

                          Colors.amber,

                          friends.where((e) => e["favorite"]).length.toString(),

                          l10n.friendsStatFavoritesLabel,
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: _statCard(
                          Icons.verified,

                          Colors.cyan,

                          friends.where((e) => e["verified"]).length.toString(),

                          l10n.friendsStatVerifiedLabel,
                        ),
                      ),
                    ],
                  ),

                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),

                    height: searching ? 65 : 0,

                    margin: EdgeInsets.only(top: searching ? 25 : 0),

                    child: TextField(
                      controller: searchController,

                      style: const TextStyle(color: Colors.white),

                      decoration: InputDecoration(
                        filled: true,

                        fillColor: const Color(0xff171725),

                        hintText: l10n.friendsSearchHint,

                        hintStyle: TextStyle(color: Colors.grey.shade500),

                        prefixIcon: const Icon(
                          Icons.search,

                          color: Colors.white70,
                        ),

                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),

                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  SizedBox(
                    height: 42,

                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,

                      itemCount: tabs.length,

                      itemBuilder: (_, index) {
                        bool selected = selectedTab == index;

                        return Padding(
                          padding: const EdgeInsets.only(right: 10),

                          child: ChoiceChip(
                            label: Text(tabs[index]),

                            selected: selected,

                            selectedColor: accentColor,

                            backgroundColor: const Color(0xff171725),

                            labelStyle: TextStyle(
                              color: selected
                                  ? Colors.white
                                  : Colors.grey.shade400,
                            ),

                            onSelected: (_) {
                              setState(() {
                                selectedTab = index;

                                filterFriends();
                              });
                            },
                          ),
                        );
                      },
                    ),
                  ),

                  const SizedBox(height: 25),
                  if (filteredFriends.isEmpty)
                    _emptyState(l10n, accentColor)
                  else
                    ListView.separated(
                      shrinkWrap: true,

                      physics: const NeverScrollableScrollPhysics(),

                      itemCount: filteredFriends.length,

                      separatorBuilder: (_, __) => const SizedBox(height: 15),

                      itemBuilder: (_, index) {
                        final friend = filteredFriends[index];

                        return TweenAnimationBuilder<double>(
                          duration: Duration(milliseconds: 250 + (index * 70)),

                          tween: Tween(begin: .90, end: 1),

                          curve: Curves.easeOutBack,

                          builder: (_, value, child) {
                            return Transform.scale(scale: value, child: child);
                          },

                          child: GestureDetector(
                            onTap: () {
                              // TODO:
                              // Abrir perfil
                            },

                            child: Container(
                              padding: const EdgeInsets.all(15),

                              decoration: BoxDecoration(
                                color: const Color(0xff171725),

                                borderRadius: BorderRadius.circular(22),

                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(.25),

                                    blurRadius: 15,

                                    offset: const Offset(0, 8),
                                  ),
                                ],
                              ),

                              child: Row(
                                children: [
                                  Stack(
                                    children: [
                                      Hero(
                                        tag: "friend_$index",

                                        child: CircleAvatar(
                                          radius: 34,

                                          backgroundImage: AssetImage(
                                            friend["avatar"],
                                          ),
                                        ),
                                      ),

                                      if (friend["online"])
                                        Positioned(
                                          right: 0,

                                          bottom: 0,

                                          child: Container(
                                            width: 16,

                                            height: 16,

                                            decoration: BoxDecoration(
                                              color: Colors.green,

                                              shape: BoxShape.circle,

                                              border: Border.all(
                                                color: const Color(0xff171725),

                                                width: 2,
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),

                                  const SizedBox(width: 15),

                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,

                                      children: [
                                        Row(
                                          children: [
                                            Flexible(
                                              child: Text(
                                                friend["name"],

                                                overflow: TextOverflow.ellipsis,

                                                style: const TextStyle(
                                                  color: Colors.white,

                                                  fontWeight: FontWeight.bold,

                                                  fontSize: 17,
                                                ),
                                              ),
                                            ),

                                            if (friend["verified"])
                                              const Padding(
                                                padding: EdgeInsets.only(
                                                  left: 5,
                                                ),

                                                child: Icon(
                                                  Icons.verified,

                                                  color: Colors.lightBlue,

                                                  size: 18,
                                                ),
                                              ),

                                            if (friend["favorite"])
                                              const Padding(
                                                padding: EdgeInsets.only(
                                                  left: 5,
                                                ),

                                                child: Icon(
                                                  Icons.star,

                                                  color: Colors.amber,

                                                  size: 18,
                                                ),
                                              ),
                                          ],
                                        ),

                                        const SizedBox(height: 5),

                                        Text(
                                          friend["username"],

                                          style: TextStyle(
                                            color: Colors.grey.shade500,
                                          ),
                                        ),

                                        const SizedBox(height: 6),

                                        Row(
                                          children: [
                                            Icon(
                                              Icons.people,

                                              color: Colors.grey.shade500,

                                              size: 15,
                                            ),

                                            const SizedBox(width: 5),

                                            Text(
                                              friend["followers"],

                                              style: TextStyle(
                                                color: Colors.grey.shade400,

                                                fontSize: 12,
                                              ),
                                            ),

                                            const SizedBox(width: 12),

                                            Icon(
                                              Icons.circle,

                                              color: friend["online"]
                                                  ? Colors.green
                                                  : Colors.grey,

                                              size: 10,
                                            ),

                                            const SizedBox(width: 5),

                                            Expanded(
                                              child: Text(
                                                friend["status"],

                                                overflow: TextOverflow.ellipsis,

                                                style: TextStyle(
                                                  color: Colors.grey.shade400,

                                                  fontSize: 12,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),

                                  Column(
                                    children: [
                                      IconButton(
                                        onPressed: () {
                                          // TODO:
                                          // Abrir chat
                                        },

                                        icon: Icon(
                                          Icons.chat_bubble,

                                          color: accentColor,
                                        ),
                                      ),

                                      IconButton(
                                        onPressed: () {
                                          // TODO:
                                          // Colaborar
                                        },

                                        icon: const Icon(
                                          Icons.handshake,

                                          color: Colors.orange,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: accentColor,

        elevation: 8,

        onPressed: () {
          scrollController.animateTo(
            0,

            duration: const Duration(milliseconds: 500),

            curve: Curves.easeOut,
          );
        },

        child: const Icon(Icons.keyboard_arrow_up),
      ),
    );
  }

  Widget _statCard(IconData icon, Color color, String value, String title) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18),

      decoration: BoxDecoration(
        color: const Color(0xff171725),

        borderRadius: BorderRadius.circular(20),
      ),

      child: Column(
        children: [
          Icon(icon, color: color, size: 28),

          const SizedBox(height: 10),

          Text(
            value,

            style: const TextStyle(
              color: Colors.white,

              fontWeight: FontWeight.bold,

              fontSize: 18,
            ),
          ),

          const SizedBox(height: 5),

          Text(
            title,

            style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _emptyState(AppLocalizations l10n, Color accentColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 80),

      child: Center(
        child: Column(
          children: [
            Icon(Icons.people_outline, color: Colors.grey.shade700, size: 70),

            const SizedBox(height: 20),

            Text(
              l10n.friendsEmptyTitle,

              style: const TextStyle(
                color: Colors.white,

                fontSize: 22,

                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              l10n.friendsEmptySubtitle,

              textAlign: TextAlign.center,

              style: TextStyle(color: Colors.grey.shade500),
            ),

            const SizedBox(height: 25),

            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: accentColor,

                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),

              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(l10n.friendsEmptySnackbarMessage)),
                );
              },

              icon: const Icon(Icons.person_add),

              label: Text(l10n.friendsEmptyActionButton),
            ),
          ],
        ),
      ),
    );
  }
}
