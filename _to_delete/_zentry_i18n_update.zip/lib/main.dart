import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'package:Zentry/features/home/home_page.dart';
import 'package:Zentry/core/providers/locale_provider.dart';
import 'package:Zentry/theme/theme_controller.dart';
import 'package:Zentry/l10n/generated/app_localizations.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LocaleProvider()),
        ChangeNotifierProvider(create: (_) => ThemeController()),
      ],
      child: const ZentryApp(),
    );
  }
}

class ZentryApp extends StatefulWidget {
  const ZentryApp({super.key});

  @override
  State<ZentryApp> createState() => _ZentryAppState();
}

class _ZentryAppState extends State<ZentryApp> {
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    final themeController = context.read<ThemeController>();
    final localeProvider = context.read<LocaleProvider>();
    
    // Carga el Tema y el Idioma al mismo tiempo desde el dispositivo
    await Future.wait([
      themeController.load(),
      localeProvider.load(),
    ]);

    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Muestra una pantalla de carga mientras recupera los datos
    if (_isLoading) {
      return const MaterialApp(
        home: Scaffold(
          backgroundColor: Color(0xff09090F),
          body: Center(child: CircularProgressIndicator(color: Colors.deepPurple)),
        ),
      );
    }

    return Consumer2<LocaleProvider, ThemeController>(
      builder: (context, localeProvider, themeController, child) {
        return MaterialApp(
          title: 'Zentry App',
          debugShowCheckedModeBanner: false,
          
          localizationsDelegates: const [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],

          // Se toma directo de los .arb en lib/l10n (ver l10n.yaml). Hoy son
          // es_MX y nah — agrega un nuevo app_<locale>.arb y aparecerá aquí
          // automáticamente, sin tocar esta lista a mano.
          supportedLocales: AppLocalizations.supportedLocales,

          // Nota: los widgets nativos de Material/Cupertino (selector de
          // fecha del sistema, menú "Copiar/Pegar", etc.) no tienen datos de
          // idioma para "nah" — Flutter no lo reconoce oficialmente. Para
          // esos casos puntuales caerán de forma automática al inglés como
          // respaldo; todo el texto propio de Zentry (vía AppLocalizations)
          // sí se muestra 100% en náhuatl.
          locale: localeProvider.locale,
          
          // Aplicamos el tema oscuro/claro + el color de acento guardado
          theme: ThemeData(
            brightness: Brightness.light,
            colorScheme: ColorScheme.fromSeed(seedColor: themeController.accentColor),
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            colorScheme: ColorScheme.fromSeed(
              seedColor: themeController.accentColor, 
              brightness: Brightness.dark
            ),
          ),
          themeMode: themeController.themeMode,
          
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(
                textScaler: TextScaler.linear(themeController.textScale),
              ),
              child: child!,
            );
          },
          
          home: const HomePage(),
        );
      },
    );
  }
}