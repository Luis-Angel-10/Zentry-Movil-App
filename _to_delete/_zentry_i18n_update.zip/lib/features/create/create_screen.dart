import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:Zentry/l10n/generated/app_localizations.dart';

class CreateScreen extends StatefulWidget {
  const CreateScreen({super.key});

  @override
  State<CreateScreen> createState() => _CreateScreenState();
}

class _CreateScreenState extends State<CreateScreen>
    with TickerProviderStateMixin {
  late TabController _mainTabController;

  int selectedPostType = 0;

  bool isPublishing = false;

  /// Construye las opciones de tipo de publicación mostradas en el selector
  /// horizontal de la pestaña "Nueva publicación".
  List<String> _buildTiposPost(AppLocalizations l10n) {
    return [
      l10n.createPostTypePost,
      l10n.createPostTypeStory,
      l10n.createPostTypeReel,
    ];
  }

  final List<String> hashtags = [
    "#Arte",
    "#Música",
    "#GameDev",
    "#Programación",
    "#Diseño",
    "#PixelArt",
    "#Blender",
    "#Unity",
    "#Animación",
    "#Modelado3D",
    "#UIUX",
    "#Ilustración",
  ];

  final List<String> selectedTags = [];

  /// Construye las opciones de rol mostradas en la sección "Roles
  /// necesarios" de la pestaña "Proyecto".
  List<String> _buildRoles(AppLocalizations l10n) {
    return [
      l10n.createRoleArtist,
      l10n.createRoleMusician,
      l10n.createRoleProgrammer,
      l10n.createRoleWriter,
      l10n.createRoleEditor,
      l10n.createRoleScreenwriter,
    ];
  }

  final List<String> selectedRoles = [];

  final TextEditingController descripcionController = TextEditingController();

  final TextEditingController proyectoTituloController =
      TextEditingController();

  final TextEditingController proyectoDescripcionController =
      TextEditingController();

  final TextEditingController colaboracionTituloController =
      TextEditingController();

  final TextEditingController colaboracionDescripcionController =
      TextEditingController();

  File? selectedImage;

  File? selectedVideo;

  PlatformFile? selectedFile;

  final List<PlatformFile> archivosProyecto = [];

  VideoPlayerController? _videoController;

  bool publica = true;

  double progresoProyecto = 0.65;

  @override
  void initState() {
    super.initState();

    _mainTabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _mainTabController.dispose();

    _videoController?.dispose();

    descripcionController.dispose();

    proyectoTituloController.dispose();

    proyectoDescripcionController.dispose();

    colaboracionTituloController.dispose();

    colaboracionDescripcionController.dispose();

    super.dispose();
  }

  /// ==================================================
  /// PUBLICAR
  /// ==================================================
  Future<void> publicarContenido() async {
    final l10n = AppLocalizations.of(context)!;

    FocusScope.of(context).unfocus();

    setState(() {
      isPublishing = true;
    });

    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    setState(() {
      isPublishing = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: const Color(0xFF1A1A2E),

        elevation: 0,

        behavior: SnackBarBehavior.floating,

        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),

        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.greenAccent),

            const SizedBox(width: 12),

            Expanded(
              child: Text(
                l10n.createPublishSuccessMessage,

                style: GoogleFonts.poppins(
                  color: Colors.white,

                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );

    limpiarContenido();
  }

  /// ==================================================
  /// LIMPIAR
  /// ==================================================
  void limpiarContenido() {
    descripcionController.clear();

    selectedImage = null;

    selectedVideo = null;

    selectedFile = null;

    _videoController?.dispose();

    _videoController = null;

    selectedTags.clear();

    FocusScope.of(context).unfocus();

    setState(() {});
  }

  /// ==================================================
  /// IMAGEN
  /// ==================================================
  Future<void> pickImage() async {
    final picker = ImagePicker();

    final image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );

    if (image != null) {
      setState(() {
        selectedImage = File(image.path);

        selectedVideo = null;
      });
    }
  }

  /// ==================================================
  /// VIDEO
  /// ==================================================
  Future<void> pickVideo() async {
    final picker = ImagePicker();

    final video = await picker.pickVideo(source: ImageSource.gallery);

    if (video != null) {
      selectedVideo = File(video.path);

      _videoController?.dispose();

      _videoController = VideoPlayerController.file(selectedVideo!)
        ..initialize().then((_) {
          setState(() {});
        });

      setState(() {
        selectedImage = null;
      });
    }
  }

  /// ==================================================
  /// ARCHIVO
  /// ==================================================
  Future<void> pickFile() async {
    final result = await FilePicker.platform.pickFiles();

    if (result != null) {
      setState(() {
        selectedFile = result.files.first;
      });
    }
  }

  /// ==================================================
  /// ARCHIVOS PROYECTO
  /// ==================================================
  Future<void> pickProjectFiles() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: true);

    if (result != null) {
      setState(() {
        archivosProyecto.addAll(result.files);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final tiposPost = _buildTiposPost(l10n);
    final roles = _buildRoles(l10n);
    const background = Color(0xFF0F0F1A);

    return Scaffold(
      backgroundColor: background,

      appBar: AppBar(
        backgroundColor: background,

        elevation: 0,

        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),

          onPressed: () {
            FocusScope.of(context).unfocus();

            limpiarContenido();

            ScaffoldMessenger.of(context).clearSnackBars();
          },
        ),

        title: Text(
          l10n.createScreenTitle,

          style: GoogleFonts.poppins(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 30,
          ),
        ),

        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),

            child: ElevatedButton(
              onPressed: isPublishing ? null : publicarContenido,

              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF8B5CF6),

                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                ),

                padding: const EdgeInsets.symmetric(horizontal: 18),
              ),

              child: isPublishing
                  ? const SizedBox(
                      width: 18,
                      height: 18,

                      child: CircularProgressIndicator(
                        color: Colors.white,

                        strokeWidth: 2,
                      ),
                    )
                  : Text(
                      l10n.createPublishButton,

                      style: GoogleFonts.poppins(
                        color: Colors.white,

                        fontWeight: FontWeight.w600,
                      ),
                    ),
            ),
          ),
        ],

        bottom: TabBar(
          controller: _mainTabController,

          indicatorColor: const Color(0xFF8B5CF6),

          labelColor: Colors.white,

          unselectedLabelColor: Colors.white38,

          labelStyle: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
            fontSize: 15,
          ),

          tabs: [
            Tab(text: l10n.createTabNewPost),

            Tab(text: l10n.createTabProject),

            Tab(text: l10n.createTabCollaboration),
          ],
        ),
      ),

      body: TabBarView(
        controller: _mainTabController,

        children: [
          /// ==================================================
          /// PUBLICACIÓN
          /// ==================================================
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                SizedBox(
                  height: 42,

                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,

                    itemCount: tiposPost.length,

                    itemBuilder: (_, index) {
                      final isSelected = selectedPostType == index;

                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedPostType = index;

                            selectedFile = null;
                          });
                        },

                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),

                          margin: const EdgeInsets.only(right: 10),

                          padding: const EdgeInsets.symmetric(horizontal: 18),

                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),

                            gradient: isSelected
                                ? const LinearGradient(
                                    colors: [
                                      Color(0xFF8B5CF6),

                                      Color(0xFFEC4899),
                                    ],
                                  )
                                : null,

                            color: isSelected ? null : const Color(0xFF1A1A2E),
                          ),

                          child: Center(
                            child: Text(
                              tiposPost[index],

                              style: GoogleFonts.poppins(
                                color: Colors.white,

                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

                const SizedBox(height: 18),

                Row(
                  children: [
                    if (selectedPostType == 0) ...[
                      Expanded(
                        child: buildActionButton(
                          icon: Icons.image,

                          title: l10n.createActionImage,

                          onTap: pickImage,
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: buildActionButton(
                          icon: Icons.videocam,

                          title: l10n.createActionVideo,

                          onTap: pickVideo,
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: buildActionButton(
                          icon: Icons.attach_file,

                          title: l10n.createActionFile,

                          onTap: pickFile,
                        ),
                      ),
                    ],

                    if (selectedPostType == 1) ...[
                      Expanded(
                        child: buildActionButton(
                          icon: Icons.image,

                          title: l10n.createActionImage,

                          onTap: pickImage,
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: buildActionButton(
                          icon: Icons.videocam,

                          title: l10n.createActionVideo,

                          onTap: pickVideo,
                        ),
                      ),
                    ],

                    if (selectedPostType == 2)
                      Expanded(
                        child: buildActionButton(
                          icon: Icons.video_collection,

                          title: l10n.createActionSelectReel,

                          onTap: pickVideo,
                        ),
                      ),
                  ],
                ),

                const SizedBox(height: 18),

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),

                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A2E),

                    borderRadius: BorderRadius.circular(18),
                  ),

                  child: Row(
                    children: [
                      const Icon(
                        Icons.verified_user,

                        color: Color(0xFF8B5CF6),

                        size: 18,
                      ),

                      const SizedBox(width: 10),

                      Expanded(
                        child: Text(
                          l10n.createContentGuidelineText,

                          style: GoogleFonts.poppins(
                            color: Colors.white60,

                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),
                if (selectedImage != null) buildImagePreview(),

                if (selectedVideo != null &&
                    _videoController != null &&
                    _videoController!.value.isInitialized)
                  buildVideoPreview(),

                if (selectedFile != null && selectedPostType == 0)
                  buildFilePreview(selectedFile!, l10n),

                if (selectedImage != null ||
                    selectedVideo != null ||
                    selectedFile != null)
                  const SizedBox(height: 18),

                buildInput(
                  controller: descripcionController,

                  hint: l10n.createPostHint,

                  maxLines: 4,
                ),

                const SizedBox(height: 22),

                buildSectionTitle(l10n.createSectionHashtags),

                const SizedBox(height: 15),

                Wrap(
                  spacing: 10,
                  runSpacing: 10,

                  children: hashtags.map((tag) {
                    final selected = selectedTags.contains(tag);

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          if (selected) {
                            selectedTags.remove(tag);
                          } else {
                            selectedTags.add(tag);
                          }
                        });
                      },

                      child: buildSelectableTag(tag, selected),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),

          /// ==================================================
          /// PROYECTOS
          /// ==================================================
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                buildInput(
                  controller: proyectoTituloController,

                  hint: l10n.createProjectTitleHint,
                ),

                const SizedBox(height: 18),

                buildInput(
                  controller: proyectoDescripcionController,

                  hint: l10n.createProjectDescriptionHint,

                  maxLines: 5,
                ),

                const SizedBox(height: 25),

                buildSectionTitle(l10n.createSectionProgress),

                const SizedBox(height: 12),

                ClipRRect(
                  borderRadius: BorderRadius.circular(20),

                  child: LinearProgressIndicator(
                    value: progresoProyecto,

                    minHeight: 12,

                    backgroundColor: Colors.white10,

                    valueColor: const AlwaysStoppedAnimation(Color(0xFF8B5CF6)),
                  ),
                ),

                const SizedBox(height: 10),

                Text(
                  l10n.createProjectProgressPercent(
                    (progresoProyecto * 100).toInt(),
                  ),

                  style: GoogleFonts.poppins(color: Colors.white54),
                ),

                Slider(
                  value: progresoProyecto,

                  activeColor: const Color(0xFF8B5CF6),

                  onChanged: (value) {
                    setState(() {
                      progresoProyecto = value;
                    });
                  },
                ),

                const SizedBox(height: 22),

                buildSectionTitle(l10n.createSectionRolesNeeded),

                const SizedBox(height: 15),

                Wrap(
                  spacing: 10,
                  runSpacing: 10,

                  children: roles.map((rol) {
                    final selected = selectedRoles.contains(rol);

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          if (selected) {
                            selectedRoles.remove(rol);
                          } else {
                            selectedRoles.add(rol);
                          }
                        });
                      },

                      child: buildSelectableTag(rol, selected),
                    );
                  }).toList(),
                ),

                const SizedBox(height: 22),

                buildSectionTitle(l10n.createSectionHashtags),

                const SizedBox(height: 15),

                Wrap(
                  spacing: 10,
                  runSpacing: 10,

                  children: hashtags.map((tag) {
                    final selected = selectedTags.contains(tag);

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          if (selected) {
                            selectedTags.remove(tag);
                          } else {
                            selectedTags.add(tag);
                          }
                        });
                      },

                      child: buildSelectableTag(tag, selected),
                    );
                  }).toList(),
                ),

                const SizedBox(height: 25),

                buildSectionTitle(l10n.createSectionProjectFiles),

                const SizedBox(height: 15),

                buildUploadCard(l10n),

                const SizedBox(height: 18),

                ...archivosProyecto.map((file) {
                  return buildProjectFileCard(file, l10n);
                }),
              ],
            ),
          ),

          /// ==================================================
          /// COLABORACIÓN
          /// ==================================================
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                buildInput(
                  controller: colaboracionTituloController,

                  hint: l10n.createCollabSearchHint,
                ),

                const SizedBox(height: 18),

                buildInput(
                  controller: colaboracionDescripcionController,

                  hint: l10n.createCollabDescriptionHint,

                  maxLines: 5,
                ),

                const SizedBox(height: 25),

                buildSectionTitle(l10n.createSectionSkills),

                const SizedBox(height: 15),

                Wrap(
                  spacing: 10,
                  runSpacing: 10,

                  children: hashtags.map((tag) {
                    final selected = selectedTags.contains(tag);

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          if (selected) {
                            selectedTags.remove(tag);
                          } else {
                            selectedTags.add(tag);
                          }
                        });
                      },

                      child: buildSelectableTag(tag, selected),
                    );
                  }).toList(),
                ),

                const SizedBox(height: 28),

                Container(
                  padding: const EdgeInsets.all(20),

                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A2E),

                    borderRadius: BorderRadius.circular(24),
                  ),

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [
                          Text(
                            l10n.createPublicCollabTitle,

                            style: GoogleFonts.poppins(
                              color: Colors.white,

                              fontWeight: FontWeight.w600,
                            ),
                          ),

                          const SizedBox(height: 5),

                          Text(
                            l10n.createPublicCollabSubtitle,

                            style: GoogleFonts.poppins(
                              color: Colors.white54,

                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),

                      Switch(
                        value: publica,

                        activeColor: const Color(0xFF8B5CF6),

                        onChanged: (v) {
                          setState(() {
                            publica = v;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildInput({
    required TextEditingController controller,
    required String hint,
    int maxLines = 1,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),

        borderRadius: BorderRadius.circular(22),
      ),

      child: TextField(
        controller: controller,

        maxLines: maxLines,

        style: GoogleFonts.poppins(color: Colors.white),

        decoration: InputDecoration(
          border: InputBorder.none,

          contentPadding: const EdgeInsets.all(18),

          hintText: hint,

          hintStyle: GoogleFonts.poppins(color: Colors.white38),
        ),
      ),
    );
  }

  Widget buildActionButton({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,

      child: Container(
        height: 55,

        decoration: BoxDecoration(
          color: const Color(0xFF1A1A2E),

          borderRadius: BorderRadius.circular(18),
        ),

        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            Icon(icon, color: const Color(0xFF8B5CF6), size: 20),

            const SizedBox(width: 8),

            Text(
              title,

              style: GoogleFonts.poppins(
                color: Colors.white,

                fontWeight: FontWeight.w500,

                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// ==================================================
  /// PREVIEW IMAGEN
  /// ==================================================
  Widget buildImagePreview() {
    return Padding(
      padding: const EdgeInsets.only(top: 22),

      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(22),

            child: Container(
              width: double.infinity,
              height: 220,

              color: Colors.black,

              child: Image.file(selectedImage!, fit: BoxFit.cover),
            ),
          ),

          /// ELIMINAR
          Positioned(
            top: 10,
            right: 10,

            child: GestureDetector(
              onTap: () {
                setState(() {
                  selectedImage = null;
                });
              },

              child: Container(
                width: 38,
                height: 38,

                decoration: BoxDecoration(
                  color: Colors.black54,

                  borderRadius: BorderRadius.circular(50),
                ),

                child: const Icon(Icons.close, color: Colors.white, size: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// ==================================================
  /// PREVIEW VIDEO
  /// ==================================================
  Widget buildVideoPreview() {
    return Padding(
      padding: const EdgeInsets.only(top: 22),

      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(22),

            child: Container(
              width: double.infinity,
              height: 220,

              color: Colors.black,

              child: FittedBox(
                fit: BoxFit.cover,

                child: SizedBox(
                  width: _videoController!.value.size.width,

                  height: _videoController!.value.size.height,

                  child: VideoPlayer(_videoController!),
                ),
              ),
            ),
          ),

          /// PLAY / PAUSE
          Positioned.fill(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  if (_videoController!.value.isPlaying) {
                    _videoController!.pause();
                  } else {
                    _videoController!.play();
                  }
                });
              },

              child: Center(
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 200),

                  opacity: _videoController!.value.isPlaying ? 0 : 1,

                  child: Container(
                    width: 75,
                    height: 75,

                    decoration: BoxDecoration(
                      color: Colors.black54,

                      borderRadius: BorderRadius.circular(50),
                    ),

                    child: Icon(
                      _videoController!.value.isPlaying
                          ? Icons.pause
                          : Icons.play_arrow,

                      color: Colors.white,

                      size: 42,
                    ),
                  ),
                ),
              ),
            ),
          ),

          /// ELIMINAR VIDEO
          Positioned(
            top: 10,
            right: 10,

            child: GestureDetector(
              onTap: () {
                _videoController?.dispose();

                _videoController = null;

                setState(() {
                  selectedVideo = null;
                });
              },

              child: Container(
                width: 38,
                height: 38,

                decoration: BoxDecoration(
                  color: Colors.black54,

                  borderRadius: BorderRadius.circular(50),
                ),

                child: const Icon(Icons.close, color: Colors.white, size: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// ==================================================
  /// FILE PREVIEW
  /// ==================================================
  Widget buildFilePreview(PlatformFile file, AppLocalizations l10n) {
    return Padding(
      padding: const EdgeInsets.only(top: 22),

      child: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(18),

            decoration: BoxDecoration(
              color: const Color(0xFF1A1A2E),

              borderRadius: BorderRadius.circular(24),
            ),

            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,

                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)],
                    ),

                    borderRadius: BorderRadius.circular(16),
                  ),

                  child: const Icon(Icons.description, color: Colors.white),
                ),

                const SizedBox(width: 15),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Text(
                        file.name,

                        maxLines: 1,

                        overflow: TextOverflow.ellipsis,

                        style: GoogleFonts.poppins(
                          color: Colors.white,

                          fontWeight: FontWeight.w500,
                        ),
                      ),

                      const SizedBox(height: 4),

                      Text(
                        l10n.createFileSizeKb(
                          (file.size / 1024).toStringAsFixed(1),
                        ),

                        style: GoogleFonts.poppins(
                          color: Colors.white54,

                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          /// ELIMINAR ARCHIVO
          Positioned(
            top: 10,
            right: 10,

            child: GestureDetector(
              onTap: () {
                setState(() {
                  selectedFile = null;
                });
              },

              child: Container(
                width: 34,
                height: 34,

                decoration: BoxDecoration(
                  color: Colors.black54,

                  borderRadius: BorderRadius.circular(50),
                ),

                child: const Icon(Icons.close, color: Colors.white, size: 18),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildUploadCard(AppLocalizations l10n) {
    return GestureDetector(
      onTap: pickProjectFiles,

      child: Container(
        width: double.infinity,

        padding: const EdgeInsets.all(22),

        decoration: BoxDecoration(
          color: const Color(0xFF1A1A2E),

          borderRadius: BorderRadius.circular(24),
        ),

        child: Column(
          children: [
            Container(
              width: 65,
              height: 65,

              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)],
                ),

                borderRadius: BorderRadius.circular(22),
              ),

              child: const Icon(
                Icons.cloud_upload,
                color: Colors.white,
                size: 34,
              ),
            ),

            const SizedBox(height: 18),

            Text(
              l10n.createUploadFilesTitle,

              style: GoogleFonts.poppins(
                color: Colors.white,

                fontWeight: FontWeight.w600,

                fontSize: 17,
              ),
            ),

            const SizedBox(height: 5),

            Text(
              l10n.createUploadFilesSubtitle,

              textAlign: TextAlign.center,

              style: GoogleFonts.poppins(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildProjectFileCard(PlatformFile file, AppLocalizations l10n) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),

      padding: const EdgeInsets.all(16),

      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),

        borderRadius: BorderRadius.circular(20),
      ),

      child: Row(
        children: [
          const Icon(
            Icons.insert_drive_file,

            color: Color(0xFF8B5CF6),

            size: 32,
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  file.name,

                  maxLines: 1,

                  overflow: TextOverflow.ellipsis,

                  style: GoogleFonts.poppins(
                    color: Colors.white,

                    fontWeight: FontWeight.w500,
                  ),
                ),

                const SizedBox(height: 3),

                Text(
                  l10n.createFileSizeKb(
                    (file.size / 1024).toStringAsFixed(1),
                  ),

                  style: GoogleFonts.poppins(
                    color: Colors.white54,

                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSectionTitle(String title) {
    return Text(
      title,

      style: GoogleFonts.poppins(
        color: Colors.white,

        fontWeight: FontWeight.w600,

        fontSize: 17,
      ),
    );
  }

  Widget buildSelectableTag(String text, bool selected) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),

      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),

        gradient: selected
            ? const LinearGradient(
                colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)],
              )
            : null,

        color: selected ? null : const Color(0xFF1A1A2E),
      ),

      child: Text(
        text,

        style: GoogleFonts.poppins(
          color: Colors.white,

          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
