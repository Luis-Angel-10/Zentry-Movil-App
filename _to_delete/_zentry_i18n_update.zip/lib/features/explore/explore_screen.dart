import 'package:Zentry/features/achievements/achievements_screen.dart';
import 'package:Zentry/features/explore/category_detail_screen.dart';
import 'package:Zentry/features/profile/creator_detail_screen.dart';
import 'package:Zentry/features/subscription/subscription_screen.dart';
import 'package:Zentry/l10n/generated/app_localizations.dart';
import 'package:flutter/material.dart';

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({super.key});

  List<Map<String, dynamic>> _buildCategorias(AppLocalizations l10n) {
    return [
      {'nombre': l10n.exploreCategoryVisualArt, 'creadores': '12.5K', 'icono': Icons.palette, 'color': Colors.purple},
      {'nombre': l10n.exploreCategoryMusic, 'creadores': '8.3K', 'icono': Icons.music_note, 'color': Colors.blue},
      {'nombre': l10n.exploreCategoryLiterature, 'creadores': '6.7K', 'icono': Icons.menu_book, 'color': Colors.green},
      {'nombre': l10n.exploreCategoryVideogames, 'creadores': '9.2K', 'icono': Icons.sports_esports, 'color': Colors.orange},
      {'nombre': l10n.exploreCategoryPhotography, 'creadores': '5.1K', 'icono': Icons.photo_camera, 'color': Colors.red},
      {'nombre': l10n.exploreCategoryDesign, 'creadores': '7.8K', 'icono': Icons.design_services, 'color': Colors.teal},
    ];
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final categorias = _buildCategorias(l10n);
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              // 🔥 TITLE
              const Text(
                'Zentry',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 20),

              // 🔥 MENU
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildMenuItem(
                      'Messages',
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Go to Messages')),
                        );
                      },
                    ),
                    const SizedBox(width: 20),

                    _buildMenuItem(
                      'Achievements',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AchievementsScreen(),
                          ),
                        );
                      },
                    ),
                    const SizedBox(width: 20),

                    // 🚀 SUBS FUNCIONANDO
                    _buildMenuItem(
                      'Subscriptions',
                      isPremium: true,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const SubscriptionScreen(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // 🔥 CATEGORIES TITLE
              const Text(
                'Categories',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 16),

              // 🔥 GRID
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.3,
                  ),
                  itemCount: categorias.length,
                  itemBuilder: (context, index) {
                    final cat = categorias[index];

                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CategoryDetailScreen(
                              category: cat['nombre'],
                              color: cat['color'],
                            ),
                          ),
                        );
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: cat['color'].withOpacity(0.2),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: cat['color'].withOpacity(0.5),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(cat['icono'],
                                color: cat['color'], size: 32),
                            const SizedBox(height: 12),
                            Text(
                              cat['nombre'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '${cat['creadores']} creators',
                              style: TextStyle(
                                color: Colors.grey[400],
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 16),

              // 🔥 FEATURED CREATORS
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Featured Creators',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: const Text('See all',
                        style: TextStyle(color: Colors.blue)),
                  ),
                ],
              ),

              const SizedBox(height: 8),

              SizedBox(
                height: 80,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 5,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CreatorDetailScreen(
                              name: 'Creator ${index + 1}',
                            ),
                          ),
                        );
                      },
                      child: Container(
                        width: 70,
                        margin: const EdgeInsets.only(right: 12),
                        child: Column(
                          children: [
                            CircleAvatar(
                              radius: 25,
                              backgroundColor:
                                  Colors.blue.withOpacity(0.3),
                              child: const Icon(Icons.person,
                                  color: Colors.blue),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Creator ${index + 1}',
                              style: TextStyle(
                                color: Colors.grey[400],
                                fontSize: 12,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 🔥 MENU ITEM PRO
  Widget _buildMenuItem(String text,
      {required VoidCallback onTap, bool isPremium = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: isPremium
              ? Colors.purple.withOpacity(0.2)
              : Colors.transparent,
        ),
        child: Text(
          text,
          style: TextStyle(
            color: isPremium
                ? Colors.purpleAccent
                : Colors.grey[400],
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}