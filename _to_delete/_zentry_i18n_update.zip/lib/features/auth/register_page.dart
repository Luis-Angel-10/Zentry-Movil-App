import 'dart:async';
import 'package:flutter/material.dart';
import 'package:Zentry/features/home/home_page.dart';
import 'package:Zentry/l10n/generated/app_localizations.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() =>
      _RegisterPageState();
}

class _RegisterPageState
    extends State<RegisterPage>
    with SingleTickerProviderStateMixin {

  /// =====================================
  /// VARIABLES
  /// =====================================

  int currentStep = 0;

  bool isLoading = false;

  bool obscurePassword = true;

  final PageController pageController =
      PageController();

  late AnimationController
      animationController;

  late Animation<double>
      fadeAnimation;

  /// =====================================
  /// CONTROLLERS
  /// =====================================

  final TextEditingController
      nombreController =
      TextEditingController();

  final TextEditingController
      artistaController =
      TextEditingController();

  final TextEditingController
      usernameController =
      TextEditingController();

  final TextEditingController
      correoController =
      TextEditingController();

  final TextEditingController
      passwordController =
      TextEditingController();

  final TextEditingController
      descripcionController =
      TextEditingController();

  /// =====================================
  /// DISCIPLINAS
  /// =====================================

  String disciplinaSeleccionada =
      "";

  List<Map<String, String>> _buildDisciplinas(AppLocalizations l10n) {
    return [

    {
      "emoji": "🎨",
      "nombre": l10n.authRegisterDisciplineIllustration,
    },

    {
      "emoji": "🎵",
      "nombre": l10n.authRegisterDisciplineMusic,
    },

    {
      "emoji": "📸",
      "nombre": l10n.authRegisterDisciplinePhotography,
    },

    {
      "emoji": "✍️",
      "nombre": l10n.authRegisterDisciplineWriting,
    },

    {
      "emoji": "🖌️",
      "nombre": l10n.authRegisterDisciplineDesign,
    },

    {
      "emoji": "🎬",
      "nombre": l10n.authRegisterDisciplineVideo,
    },

    {
      "emoji": "🗿",
      "nombre": l10n.authRegisterDisciplineSculpture,
    },

    {
      "emoji": "🏛️",
      "nombre": l10n.authRegisterDisciplineArchitecture,
    },

    {
      "emoji": "🎭",
      "nombre": l10n.authRegisterDisciplinePerformance,
    },

    {
      "emoji": "✨",
      "nombre": l10n.authRegisterDisciplineOther,
    },
  ];
  }

  /// =====================================
  /// INIT
  /// =====================================

  @override
  void initState() {

    super.initState();

    animationController =
        AnimationController(
      vsync: this,

      duration:
          const Duration(
        seconds: 2,
      ),
    )..repeat(reverse: true);

    fadeAnimation =
        Tween<double>(
      begin: 0.7,
      end: 1,
    ).animate(animationController);
  }

  @override
  void dispose() {

    animationController.dispose();

    pageController.dispose();

    nombreController.dispose();

    artistaController.dispose();

    usernameController.dispose();

    correoController.dispose();

    passwordController.dispose();

    descripcionController.dispose();

    super.dispose();
  }

  /// =====================================
  /// REGISTER
  /// =====================================

  Future<void> registrar() async {

    if (isLoading) return;

    setState(() {

      isLoading = true;
    });

    await Future.delayed(
      const Duration(seconds: 2),
    );

    if (!mounted) return;

    Navigator.pushReplacement(
      context,

      MaterialPageRoute(
        builder: (_) =>
            const HomePage(),
      ),
    );
  }

  void siguientePaso() {

    if (currentStep < 2) {

      setState(() {

        currentStep++;
      });

      pageController.nextPage(
        duration:
            const Duration(
          milliseconds: 300,
        ),

        curve: Curves.easeInOut,
      );

    } else {

      registrar();
    }
  }

  void regresarPaso() {

    if (currentStep > 0) {

      setState(() {

        currentStep--;
      });

      pageController.previousPage(
        duration:
            const Duration(
          milliseconds: 300,
        ),

        curve: Curves.easeInOut,
      );
    }
  }

  /// =====================================
  /// UI
  /// =====================================

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      resizeToAvoidBottomInset:
          true,

      backgroundColor:
          const Color(0xFF07070D),

      body: Stack(
        children: [

          /// BACKGROUND
          Container(
            decoration:
                const BoxDecoration(
              gradient:
                  LinearGradient(
                begin:
                    Alignment.topCenter,

                end:
                    Alignment.bottomCenter,

                colors: [

                  Color(0xFF1A1030),
                  Color(0xFF07070D),
                ],
              ),
            ),
          ),

          /// CONTENT
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding:
                    const EdgeInsets.all(
                        20),

                child: ConstrainedBox(
                  constraints:
                      const BoxConstraints(
                    maxWidth: 520,
                  ),

                  child: Container(
                    padding:
                        const EdgeInsets.all(
                            28),

                    decoration:
                        BoxDecoration(
                      color:
                          const Color(
                              0xFF17171F),

                      borderRadius:
                          BorderRadius.circular(
                              30),

                      border:
                          Border.all(
                        color:
                            Colors.white10,
                      ),
                    ),

                    child: Column(
                      mainAxisSize:
                          MainAxisSize.min,

                      children: [

                        /// LOGO
                        FadeTransition(
                          opacity:
                              fadeAnimation,

                          child: const Text(
                            "Zentry",

                            style:
                                TextStyle(
                              color:
                                  Colors.white,

                              fontSize:
                                  42,

                              fontWeight:
                                  FontWeight.bold,

                              letterSpacing:
                                  1.2,
                            ),
                          ),
                        ),

                        const SizedBox(
                            height: 15),

                        Text(
                          l10n.authRegisterHeadline,

                          textAlign:
                              TextAlign.center,

                          style:
                              const TextStyle(
                            color:
                                Colors.white,

                            fontSize:
                                28,

                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),

                        const SizedBox(
                            height: 10),

                        Text(
                          l10n.authRegisterSubheading,

                          textAlign:
                              TextAlign.center,

                          style:
                              const TextStyle(
                            color:
                                Colors.white54,

                            fontSize:
                                15,
                          ),
                        ),

                        const SizedBox(
                            height: 28),

                        buildIndicadores(),

                        const SizedBox(
                            height: 30),

                        AnimatedSwitcher(
                          duration:
                              const Duration(
                            milliseconds:
                                300,
                          ),

                          child:
                              currentStep == 0

                                  ? buildPasoUno()

                                  : currentStep ==
                                          1

                                      ? buildPasoDos()

                                      : buildPasoTres(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          /// LOADING
          if (isLoading)

            Container(
              color:
                  Colors.black54,

              child: const Center(
                child:
                    CircularProgressIndicator(
                  color:
                      Color(0xFF8B5CF6),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// =====================================
  /// INDICADORES
  /// =====================================

  Widget buildIndicadores() {

    return Row(
      mainAxisAlignment:
          MainAxisAlignment.center,

      children: List.generate(
        3,
        (index) {

          bool activo =
              currentStep ==
                  index;

          return AnimatedContainer(
            duration:
                const Duration(
              milliseconds: 250,
            ),

            margin:
                const EdgeInsets.symmetric(
              horizontal: 5,
            ),

            width:
                activo ? 32 : 10,

            height: 10,

            decoration:
                BoxDecoration(
              color: activo

                  ? const Color(
                      0xFF8B5CF6)

                  : Colors.white24,

              borderRadius:
                  BorderRadius.circular(
                      20),
            ),
          );
        },
      ),
    );
  }

  /// =====================================
  /// PASO 1
  /// =====================================

  Widget buildPasoUno() {
    final l10n = AppLocalizations.of(context)!;

    return Column(
      key: const ValueKey(1),

      children: [

        buildInput(
          l10n.authRegisterFullNameHint,
          nombreController,
        ),

        const SizedBox(height: 18),

        buildInput(
          l10n.authRegisterArtistNameHint,
          artistaController,
        ),

        const SizedBox(height: 18),

        buildInput(
          l10n.authRegisterUsernameHint,
          usernameController,
        ),

        const SizedBox(height: 18),

        buildInput(
          l10n.authRegisterEmailHint,
          correoController,
        ),

        const SizedBox(height: 18),

        TextField(
          controller:
              passwordController,

          obscureText:
              obscurePassword,

          style:
              const TextStyle(
            color: Colors.white,
          ),

          decoration:
              decoracionInput(
            l10n.authRegisterPasswordHint,
          ).copyWith(

            suffixIcon:
                IconButton(
              icon: Icon(
                obscurePassword

                    ? Icons.visibility_off

                    : Icons.visibility,

                color:
                    Colors.white54,
              ),

              onPressed: () {

                setState(() {

                  obscurePassword =
                      !obscurePassword;
                });
              },
            ),
          ),
        ),

        const SizedBox(height: 30),

        buildBoton(
          l10n.commonContinue,
          siguientePaso,
        ),
      ],
    );
  }

  /// =====================================
  /// PASO 2
  /// =====================================

  Widget buildPasoDos() {
    final l10n = AppLocalizations.of(context)!;
    final disciplinas = _buildDisciplinas(l10n);

    return Column(
      key: const ValueKey(2),

      crossAxisAlignment:
          CrossAxisAlignment.start,

      children: [

        Text(
          l10n.authRegisterDisciplineTitle,

          style: const TextStyle(
            color: Colors.white,

            fontSize: 24,

            fontWeight:
                FontWeight.bold,
          ),
        ),

        const SizedBox(height: 8),

        Text(
          l10n.authRegisterDisciplineSubtitle,

          style: const TextStyle(
            color: Colors.white54,
          ),
        ),

        const SizedBox(height: 24),

        GridView.builder(
          shrinkWrap: true,

          physics:
              const NeverScrollableScrollPhysics(),

          itemCount:
              disciplinas.length,

          gridDelegate:
              const SliverGridDelegateWithFixedCrossAxisCount(

            crossAxisCount: 2,

            mainAxisSpacing: 14,

            crossAxisSpacing: 14,

            childAspectRatio: 2.6,
          ),

          itemBuilder:
              (_, index) {

            final item =
                disciplinas[index];

            final selected =
                disciplinaSeleccionada ==
                item["nombre"];

            return GestureDetector(
              onTap: () {

                setState(() {

                  disciplinaSeleccionada =
                      item["nombre"]!;
                });
              },

              child:
                  AnimatedContainer(
                duration:
                    const Duration(
                  milliseconds:
                      250,
                ),

                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 16,
                ),

                decoration:
                    BoxDecoration(

                  borderRadius:
                      BorderRadius.circular(
                          18),

                  gradient:
                      selected
                          ? const LinearGradient(
                              colors: [

                                Color(
                                    0xFF8B5CF6),

                                Color(
                                    0xFFD946EF),
                              ],
                            )
                          : null,

                  color:
                      selected

                          ? null

                          : const Color(
                              0xFF24242C),
                ),

                child: Row(
                  children: [

                    Text(
                      item["emoji"]!,

                      style:
                          const TextStyle(
                        fontSize: 22,
                      ),
                    ),

                    const SizedBox(
                        width: 10),

                    Expanded(
                      child: Text(
                        item["nombre"]!,

                        style:
                            const TextStyle(
                          color:
                              Colors.white,

                          fontWeight:
                              FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),

        const SizedBox(height: 30),

        Row(
          children: [

            Expanded(
              child:
                  buildBotonSecundario(
                l10n.commonBack,
                regresarPaso,
              ),
            ),

            const SizedBox(width: 14),

            Expanded(
              child: buildBoton(
                l10n.commonContinue,
                siguientePaso,
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// =====================================
  /// PASO 3
  /// =====================================

  Widget buildPasoTres() {
    final l10n = AppLocalizations.of(context)!;

    return Column(
      key: const ValueKey(3),

      crossAxisAlignment:
          CrossAxisAlignment.start,

      children: [

        Text(
          l10n.authRegisterAboutTitle,

          style: const TextStyle(
            color: Colors.white,

            fontSize: 24,

            fontWeight:
                FontWeight.bold,
          ),
        ),

        const SizedBox(height: 8),

        Text(
          l10n.authRegisterAboutSubtitle,

          style: const TextStyle(
            color: Colors.white54,
          ),
        ),

        const SizedBox(height: 24),

        TextField(
          controller:
              descripcionController,

          maxLines: 6,

          style:
              const TextStyle(
            color: Colors.white,
          ),

          decoration:
              decoracionInput(

            l10n.authRegisterBioHint,
          ),
        ),

        const SizedBox(height: 30),

        Row(
          children: [

            Expanded(
              child:
                  buildBotonSecundario(
                l10n.commonBack,
                regresarPaso,
              ),
            ),

            const SizedBox(width: 14),

            Expanded(
              child: buildBoton(
                l10n.authRegisterFinishButton,
                registrar,
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// =====================================
  /// INPUTS
  /// =====================================

  Widget buildInput(
    String hint,
    TextEditingController
        controller,
  ) {

    return TextField(
      controller: controller,

      style: const TextStyle(
        color: Colors.white,
      ),

      decoration:
          decoracionInput(hint),
    );
  }

  InputDecoration decoracionInput(
      String hint) {

    return InputDecoration(
      hintText: hint,

      hintStyle:
          const TextStyle(
        color: Colors.white38,
      ),

      filled: true,

      fillColor:
          const Color(0xFF24242C),

      contentPadding:
          const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 18,
      ),

      border: OutlineInputBorder(
        borderRadius:
            BorderRadius.circular(
                18),

        borderSide:
            BorderSide.none,
      ),
    );
  }


  Widget buildBoton(
    String texto,
    VoidCallback onTap,
  ) {

    return SizedBox(
      height: 56,

      child: ElevatedButton(
        onPressed: onTap,

        style:
            ElevatedButton.styleFrom(

          backgroundColor:
              const Color(
                  0xFF8B5CF6),

          elevation: 0,

          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(
                    18),
          ),
        ),

        child: Text(
          texto,

          style: const TextStyle(
            color: Colors.white,

            fontSize: 16,

            fontWeight:
                FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget buildBotonSecundario(
    String texto,
    VoidCallback onTap,
  ) {

    return SizedBox(
      height: 56,

      child: OutlinedButton(
        onPressed: onTap,

        style:
            OutlinedButton.styleFrom(

          side: BorderSide(
            color:
                Colors.white10,
          ),

          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(
                    18),
          ),
        ),

        child: Text(
          texto,

          style: const TextStyle(
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}