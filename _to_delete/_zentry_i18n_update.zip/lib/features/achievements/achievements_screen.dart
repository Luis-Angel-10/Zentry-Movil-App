import 'package:flutter/material.dart';
import 'package:Zentry/l10n/generated/app_localizations.dart';

class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: const Color(0xFF0B0B0F),
      appBar: AppBar(
        title: Text(l10n.achievementsScreenTitle),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            Row(
              children: [
                _stat("5/7", l10n.achievementsUnlockedStat),
                _stat("71%", l10n.achievementsProgressStat),
                _stat("850", l10n.achievementsPointsStat),
                _stat("Gold", l10n.achievementsRankStat),
              ],
            ),

            const SizedBox(height: 20),

            _progress(l10n),

            const SizedBox(height: 20),

            _achievementCard(
              l10n: l10n,
              title: l10n.achievementsFirstPostTitle,
              desc: l10n.achievementsFirstPostDesc,
              rarity: l10n.achievementsRarityCommon,
              unlocked: true,
              color: Colors.blue,
            ),

            _achievementCard(
              l10n: l10n,
              title: l10n.achievementsPopularTitle,
              desc: l10n.achievementsPopularDesc,
              rarity: l10n.achievementsRarityCommon,
              unlocked: true,
              color: Colors.pink,
            ),

            _achievementCard(
              l10n: l10n,
              title: l10n.achievementsInfluencerTitle,
              desc: l10n.achievementsInfluencerDesc,
              rarity: l10n.achievementsRarityRare,
              progress: 0.6,
              color: Colors.blueAccent,
            ),

            _achievementCard(
              l10n: l10n,
              title: l10n.achievementsCreatorProTitle,
              desc: l10n.achievementsCreatorProDesc,
              rarity: l10n.achievementsRarityEpic,
              progress: 0.4,
              color: Colors.purple,
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String value, String label) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.all(6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [Colors.grey.shade900, Colors.grey.shade800],
          ),
        ),
        child: Column(
          children: [
            Text(value,
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white)),
            Text(label, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }


  Widget _progress(AppLocalizations l10n) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          colors: [Colors.purple, Colors.pink],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(l10n.achievementsGeneralProgressTitle,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: 0.74,
            minHeight: 8,
            backgroundColor: Colors.black,
            color: Colors.white,
          ),
        ],
      ),
    );
  }

  Widget _achievementCard({
    required AppLocalizations l10n,
    required String title,
    required String desc,
    required String rarity,
    required Color color,
    bool unlocked = false,
    double progress = 0,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [
            Colors.grey.shade900,
            color.withOpacity(0.2),
          ],
        ),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Column(
        children: [
          Row(
            children: [

              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(Icons.star, color: color),
              ),

              const SizedBox(width: 10),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold)),
                    Text(desc,
                        style: const TextStyle(color: Colors.grey)),
                  ],
                ),
              ),

              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(rarity,
                    style: TextStyle(color: color, fontSize: 12)),
              ),
            ],
          ),

          const SizedBox(height: 10),
          if (!unlocked)
            LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.grey[800],
              color: color,
            ),

          if (unlocked)
            Align(
              alignment: Alignment.centerLeft,
              child: Text(l10n.achievementsUnlockedBadge,
                  style: const TextStyle(color: Colors.green)),
            ),
        ],
      ),
    );
  }
}