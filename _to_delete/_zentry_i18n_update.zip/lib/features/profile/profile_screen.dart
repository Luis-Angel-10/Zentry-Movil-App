import 'package:flutter/material.dart';
import 'package:Zentry/l10n/generated/app_localizations.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    final List<String> posts = [

      "https://images.unsplash.com/photo-1515879218367-8466d910aaa4",

      "https://images.unsplash.com/photo-1498050108023-c5249f4df085",

      "https://images.unsplash.com/photo-1513364776144-60967b0f800f",

      "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8",

      "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4",

      "https://images.unsplash.com/photo-1511379938547-c1f69419868d",

      "https://images.unsplash.com/photo-1558655146-d09347e92766",

      "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d",

      "https://images.unsplash.com/photo-1545239351-1141bd82e8a6",

      "https://images.unsplash.com/photo-1455390582262-044cdead277a",

      "https://images.unsplash.com/photo-1492619375914-88005aa9e8fb",

      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee",
    ];

    return Scaffold(
      backgroundColor:
          const Color(0xFF09090F),

      body: SafeArea(
        child: CustomScrollView(
          physics:
              const BouncingScrollPhysics(),

          slivers: [

            /// HEADER
            SliverToBoxAdapter(
              child: Padding(
                padding:
                    const EdgeInsets.all(
                        18),

                child: Column(
                  children: [

                    Row(
                      children: [

                        /// FOTO
                        Container(
                          padding:
                              const EdgeInsets.all(
                                  3),

                          decoration:
                              BoxDecoration(
                            shape:
                                BoxShape.circle,

                            gradient:
                                const LinearGradient(
                              colors: [

                                Color(
                                    0xFF8B5CF6),

                                Color(
                                    0xFFD946EF),
                              ],
                            ),
                          ),

                          child:
                              const CircleAvatar(
                            radius: 42,

                            backgroundImage:
                                NetworkImage(
                              "https://i.pravatar.cc/300?img=12",
                            ),
                          ),
                        ),

                        const SizedBox(
                            width: 18),

                        /// INFO
                        Expanded(
                          child:
                              Column(
                            crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,

                            children: [

                              const Text(
                                "Luis Martínez",

                                style:
                                    TextStyle(
                                  color:
                                      Colors.white,

                                  fontSize:
                                      22,

                                  fontWeight:
                                      FontWeight.bold,
                                ),
                              ),

                              const SizedBox(
                                  height:
                                      4),

                              Text(
                                "Desarrollador Creativo",

                                style:
                                    TextStyle(
                                  color:
                                      Colors.grey[
                                          400],

                                  fontSize:
                                      14,
                                ),
                              ),

                              const SizedBox(
                                  height:
                                      10),

                              Text(
                                "Creando experiencias digitales, arte y tecnología 🚀",

                                style:
                                    TextStyle(
                                  color:
                                      Colors.grey[
                                          500],

                                  fontSize:
                                      13,

                                  height:
                                      1.4,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(
                        height: 24),

                    /// STATS
                    Container(
                      padding:
                          const EdgeInsets.symmetric(
                        vertical: 18,
                      ),

                      decoration:
                          BoxDecoration(
                        color:
                            const Color(
                                0xFF141420),

                        borderRadius:
                            BorderRadius.circular(
                                24),
                      ),

                      child: Row(
                        mainAxisAlignment:
                            MainAxisAlignment
                                .spaceAround,

                        children: [

                          _buildStat(
                            "120",
                            l10n.profilePostsLabel,
                          ),

                          _buildStat(
                            "3.4K",
                            l10n.profileFollowersLabel,
                          ),

                          _buildStat(
                            "210",
                            l10n.profileFollowingLabel,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(
                        height: 20),

                    /// BOTONES
                    Row(
                      children: [

                        Expanded(
                          child:
                              ElevatedButton(
                            onPressed:
                                () {},

                            style:
                                ElevatedButton.styleFrom(

                              backgroundColor:
                                  const Color(
                                      0xFF8B5CF6),

                              shape:
                                  RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(
                                        18),
                              ),

                              padding:
                                  const EdgeInsets.symmetric(
                                vertical:
                                    14,
                              ),
                            ),

                            child:
                                Text(
                              l10n.profileEditButton,

                              style:
                                  const TextStyle(
                                color:
                                    Colors.white,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(
                            width: 12),

                        Expanded(
                          child:
                              ElevatedButton(
                            onPressed:
                                () {},

                            style:
                                ElevatedButton.styleFrom(

                              backgroundColor:
                                  const Color(
                                      0xFF1A1A24),

                              shape:
                                  RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(
                                        18),
                              ),

                              padding:
                                  const EdgeInsets.symmetric(
                                vertical:
                                    14,
                              ),
                            ),

                            child:
                                Text(
                              l10n.commonShare,

                              style:
                                  const TextStyle(
                                color:
                                    Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(
                        height: 25),

                    /// TABS
                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment
                              .spaceAround,

                      children: [

                        buildTab(
                          Icons.grid_on,
                          true,
                        ),

                        buildTab(
                          Icons.video_collection_outlined,
                          false,
                        ),

                        buildTab(
                          Icons.bookmark_border,
                          false,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            /// GRID
            SliverPadding(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 4,
              ),

              sliver: SliverGrid(
                delegate:
                    SliverChildBuilderDelegate(

                  (context, index) {

                    return Container(
                      margin:
                          const EdgeInsets.all(
                              2),

                      decoration:
                          BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(
                                12),
                      ),

                      child: ClipRRect(
                        borderRadius:
                            BorderRadius.circular(
                                12),

                        child:
                            Image.network(
                          posts[index],

                          fit:
                              BoxFit.cover,

                          loadingBuilder:
                              (
                            context,
                            child,
                            progress,
                          ) {

                            if (progress ==
                                null) {

                              return child;
                            }

                            return Container(
                              color:
                                  Colors.white10,

                              child:
                                  const Center(
                                child:
                                    CircularProgressIndicator(
                                  color:
                                      Colors.deepPurpleAccent,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    );
                  },

                  childCount:
                      posts.length,
                ),

                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(

                  crossAxisCount:
                      3,

                  crossAxisSpacing:
                      4,

                  mainAxisSpacing:
                      4,
                ),
              ),
            ),

            const SliverToBoxAdapter(
              child: SizedBox(
                  height: 90),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(
    String number,
    String label,
  ) {

    return Column(
      children: [

        Text(
          number,

          style:
              const TextStyle(
            color:
                Colors.white,

            fontWeight:
                FontWeight.bold,

            fontSize: 20,
          ),
        ),

        const SizedBox(height: 4),

        Text(
          label,

          style:
              TextStyle(
            color:
                Colors.grey[400],

            fontSize: 13,
          ),
        ),
      ],
    );
  }

  Widget buildTab(
    IconData icon,
    bool active,
  ) {

    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 28,
        vertical: 10,
      ),

      decoration:
          BoxDecoration(
        color: active

            ? Colors.deepPurple
                .withOpacity(
                    0.20)

            : Colors.transparent,

        borderRadius:
            BorderRadius.circular(
                16),
      ),

      child: Icon(
        icon,

        color: active

            ? Colors.deepPurpleAccent

            : Colors.white54,
      ),
    );
  }
}